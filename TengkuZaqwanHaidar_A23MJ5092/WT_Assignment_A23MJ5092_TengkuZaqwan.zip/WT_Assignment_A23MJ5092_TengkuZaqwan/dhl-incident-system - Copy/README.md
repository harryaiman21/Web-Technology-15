# DHL Incident Reporting System — Setup Guide

## Files in This Project

```
dhl-incident-system/
├── db.json          ← Mock database (JSON Server)
├── login.html       ← Login page
├── index.html       ← Dashboard (list all incidents)
├── submit.html      ← Report new incident
├── incident.html    ← View / Edit / Delete an incident
└── README.md        ← This file
```

## How to Run

### Step 1 — Install JSON Server (one time only)
Open your terminal and run:
```
npm install -g json-server
```

### Step 2 — Start the mock API server
Navigate to the project folder, then run:
```
json-server --watch db.json --port 3000
```
You should see: `Resources: http://localhost:3000/incidents`

### Step 3 — Open the app
Open `login.html` in your browser (just double-click it, or use Live Server in VS Code).

## Demo Login Accounts

| Username | Password | Role   |
|----------|----------|--------|
| admin    | admin123 | Admin  |
| editor1  | pass123  | Editor |
| editor2  | pass123  | Editor |

## API Endpoints (used internally by the app)

| Method | Endpoint              | Action                   |
|--------|-----------------------|--------------------------|
| GET    | /incidents            | Get all incidents         |
| GET    | /incidents/:id        | Get single incident       |
| POST   | /incidents            | Create new incident       |
| PUT    | /incidents/:id        | Update incident           |
| DELETE | /incidents/:id        | Delete incident           |
| GET    | /users                | Get all users             |
| GET    | /departments          | Get all departments       |
