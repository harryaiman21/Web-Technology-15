require('dotenv').config();
const express = require('express');
const cors = require('cors');
const jsonServer = require('json-server');
const Anthropic = require('@anthropic-ai/sdk');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Anthropic client
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Middleware
app.use(cors());

// Custom JSON parser that sanitizes control characters from RPA requests
// UiPath sends raw file content inside JSON strings which breaks standard parsing
app.use((req, res, next) => {
  if (req.path.startsWith('/api/rpa') && req.method === 'POST') {
    let raw = '';
    req.setEncoding('utf8');
    req.on('data', chunk => { raw += chunk; });
    req.on('end', () => {
      try {
        // Strip control characters (newlines, tabs, carriage returns) only inside string values
        // Replace literal \r\n \n \r \t with spaces so JSON.parse succeeds
        const sanitized = raw
          .replace(/[\r\n\t]/g, ' ')   // replace control chars with space
          .replace(/\s{2,}/g, ' ');     // collapse multiple spaces
        req.body = JSON.parse(sanitized);
        next();
      } catch (e) {
        res.status(400).json({ error: 'Invalid JSON', detail: e.message });
      }
    });
  } else {
    express.json({ limit: '10mb' })(req, res, next);
  }
});

// ============================================
// JSON SERVER SETUP (must be before RPA endpoints
// so `router` is available to them)
// ============================================
const router = jsonServer.router('db.json');
const middlewares = jsonServer.defaults();

// Helper: write router's in-memory db back to disk
// AND update the in-memory db so GET /api/articles
// reflects changes immediately without a restart.
function syncDb() {
  // router.db is a lowdb instance; this persists to disk
  router.db.write();
}

// ============================================
// CLAUDE AI ENDPOINT
// ============================================
app.post('/api/claude', async (req, res) => {
  try {
    const { prompt, maxTokens = 1000, systemPrompt } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-5',
      max_tokens: maxTokens,
      messages: [
        { role: 'user', content: prompt }
      ],
      ...(systemPrompt && { system: systemPrompt })
    });

    const text = message.content
      .filter(block => block.type === 'text')
      .map(block => block.text)
      .join('\n');

    res.json({ 
      success: true,
      text,
      usage: message.usage
    });

  } catch (error) {
    console.error('Claude API Error:', error);
    res.status(500).json({ 
      error: 'AI processing failed',
      message: error.message 
    });
  }
});

// ============================================
// HEALTH CHECK
// ============================================
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok',
    claude: process.env.ANTHROPIC_API_KEY ? 'configured' : 'missing',
    timestamp: new Date().toISOString()
  });
});

// ============================================
// RPA AI STRUCTURE ENDPOINT
// UiPath calls this first with raw file content.
// Claude structures it into a proper KB article.
// Works for any file type txt, pdf, docx, image OCR output.
// ============================================
app.post('/api/rpa/structure', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== 'RPA_SECRET_KEY_DHL_2026') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { rawContent, sourceFile } = req.body;
  if (!rawContent) {
    return res.status(400).json({ error: 'rawContent is required' });
  }

  // Use Claude to structure the raw content into a proper KB article
  // Then immediately save it to the KB — no UiPath parsing needed
  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).substring(0, 8);
  }

  let structured = null;

  try {
    const fileName = (sourceFile || 'unknown').replace(/\.[^.]+$/, '').replace(/[_\-]/g, ' ');
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-5',
      max_tokens: 2000,
      messages: [{
        role: 'user',
        content: `You are a DHL Knowledge Base editor. Your job is to convert ANY raw input into a full, professional Standard Operating Procedure (SOP) article for DHL logistics staff.

IMPORTANT RULES:
1. Even if the input is very short or vague (e.g. "bad customer service"), you MUST expand it into a full SOP using your knowledge of DHL logistics operations.
2. Always generate at least 5 numbered steps in the content.
3. Always generate at least 3 relevant tags.
4. The title must be professional and specific (not just repeat the input).
5. Return ONLY a valid JSON object. No markdown, no code fences, no extra text.

JSON shape (use exactly this):
{"title": "Professional SOP title max 80 chars", "summary": "1-2 sentence summary of what this SOP covers", "content": "Full structured content with numbered steps", "tags": ["tag1", "tag2", "tag3"]}

FILE NAME: ${fileName}
RAW INPUT: ${rawContent.substring(0, 3000)}`
      }]
    });

    const text = message.content
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('');

    const clean = text.replace(/```json|```/g, '').trim();
    structured = JSON.parse(clean);
    console.log('AI structured: "' + structured.title + '" from ' + sourceFile);

  } catch (error) {
    console.error('Claude structuring failed, using raw content:', error.message);
    // Fallback: use raw content as-is
    structured = {
      title: (sourceFile || 'Untitled').replace(/\.[^.]+$/, '').replace(/[_-]/g, ' '),
      summary: rawContent.substring(0, 120),
      content: rawContent,
      tags: []
    };
  }

  // Now check for duplicates and save directly — no UiPath parsing required
  const hash = simpleHash(structured.title + structured.content);
  const now = new Date().toISOString();
  const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();

  const articles = router.db.get('articles').value();
  const duplicate = articles.find(a => a.hash === hash && a.createdAt > cutoff);

  if (duplicate) {
    router.db.get('logs').push({
      id: Date.now(), timestamp: now, action: 'RPA_SKIP_DUPLICATE',
      articleId: duplicate.id,
      details: 'Duplicate of article #' + duplicate.id + ': "' + duplicate.title + '"',
      status: 'success'
    }).write();
    return res.json({ result: 'duplicate', duplicateId: duplicate.id });
  }

  const newId = articles.length > 0 ? Math.max(...articles.map(a => a.id)) + 1 : 1;

  const newArticle = {
    id: newId,
    title: structured.title,
    summary: structured.summary || structured.content.substring(0, 120),
    content: structured.content,
    tags: structured.tags || [],
    status: 'Draft',
    creator: 'RPA_BOT',
    createdAt: now,
    updatedAt: now,
    version: 1,
    history: [{ version: 1, status: 'Draft', updatedAt: now }],
    sourceFile: sourceFile || null,
    hash
  };

  router.db.get('articles').push(newArticle).write();
  router.db.get('logs').push({
    id: Date.now(), timestamp: now, action: 'RPA_CREATE',
    articleId: newId,
    details: 'AI-structured article from file: ' + (sourceFile || 'unknown'),
    status: 'success'
  }).write();

  console.log('RPA created article #' + newId + ': "' + structured.title + '"');
  return res.json({ result: 'created', articleId: newId });
});

// ============================================
// RPA INGEST ENDPOINT
// ============================================
app.post('/api/rpa/ingest', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== 'RPA_SECRET_KEY_DHL_2026') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { title, content, sourceFile, tags } = req.body;
  if (!title || !content) {
    return res.status(400).json({ error: 'title and content required' });
  }

  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).substring(0, 8);
  }

  const hash = simpleHash(title + content);
  const now = new Date().toISOString();
  const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();

  // Use router.db (lowdb) — the live in-memory database
  const articles = router.db.get('articles').value();
  const logs = router.db.get('logs').value();

  const duplicate = articles.find(a => a.hash === hash && a.createdAt > cutoff);

  if (duplicate) {
    const skipLog = {
      id: Date.now(),
      timestamp: now,
      action: 'RPA_SKIP_DUPLICATE',
      articleId: duplicate.id,
      details: `Duplicate of article #${duplicate.id}: "${duplicate.title}"`,
      status: 'success'
    };
    router.db.get('logs').push(skipLog).write();
    return res.json({ result: 'duplicate', duplicateId: duplicate.id });
  }

  const newId = articles.length > 0
    ? Math.max(...articles.map(a => a.id)) + 1
    : 1;

  const newArticle = {
    id: newId,
    title,
    summary: content.substring(0, 120) + (content.length > 120 ? '...' : ''),
    content,
    tags: tags || [],
    status: 'Draft',
    creator: 'RPA_BOT',
    createdAt: now,
    updatedAt: now,
    version: 1,
    history: [{ version: 1, status: 'Draft', updatedAt: now }],
    sourceFile: sourceFile || null,
    hash
  };

  const createLog = {
    id: Date.now(),
    timestamp: now,
    action: 'RPA_CREATE',
    articleId: newId,
    details: `Created article from file: ${sourceFile || 'unknown'}`,
    status: 'success'
  };

  // Push to in-memory db AND write to disk in one call
  router.db.get('articles').push(newArticle).write();
  router.db.get('logs').push(createLog).write();

  console.log(`✅ RPA created article #${newId}: "${title}"`);
  return res.json({ result: 'created', articleId: newId });
});

// ============================================
// RPA ERROR ENDPOINT
// ============================================
app.post('/api/rpa/error', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== 'RPA_SECRET_KEY_DHL_2026') {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { details, sourceFile } = req.body;

  const errorLog = {
    id: Date.now(),
    timestamp: new Date().toISOString(),
    action: 'RPA_ERROR',
    articleId: null,
    details: details || 'Unknown error',
    status: 'error'
  };

  router.db.get('logs').push(errorLog).write();
  console.log(`❌ RPA error logged: ${details}`);
  res.json({ logged: true });
});

// ============================================
// JSON SERVER FOR KB DATA
// ============================================
app.use('/api', middlewares);
app.use('/api', router);

// ============================================
// START SERVER
// ============================================
app.listen(PORT, () => {
  console.log('='.repeat(50));
  console.log('🚀 DHL Knowledge Base Backend Server');
  console.log('='.repeat(50));
  console.log(`✅ Server running on http://localhost:${PORT}`);
  console.log(`📊 JSON Server API: http://localhost:${PORT}/api/articles`);
  console.log(`🤖 Claude AI Endpoint: http://localhost:${PORT}/api/claude`);
  console.log(`💚 Health Check: http://localhost:${PORT}/health`);
  console.log(`🤖 RPA Ingest: http://localhost:${PORT}/api/rpa/ingest`);
  console.log('='.repeat(50));

  if (!process.env.ANTHROPIC_API_KEY) {
    console.log('⚠️  WARNING: ANTHROPIC_API_KEY not found in .env');
  }
});
