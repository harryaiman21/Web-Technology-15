// middleware.js - Simple auth middleware for JSON Server
// Allows RPA bot access via API key header, humans via session

module.exports = (req, res, next) => {
  // Allow GET requests freely (read-only public viewer)
  if (req.method === 'GET') {
    return next();
  }

  // Check for RPA bot API key
  const apiKey = req.headers['x-api-key'];
  if (apiKey === 'RPA_SECRET_KEY_DHL_2026') {
    req.isRPA = true;
    return next();
  }

  // Check for simple auth token (set by login)
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    // In real app: validate JWT. Here we just accept any Bearer token.
    return next();
  }

  // Block unauthenticated writes
  res.status(401).json({ error: 'Unauthorized. Please login or provide API key.' });
};
