# 🚨 CRITICAL SECURITY ALERT

## YOUR API KEY HAS BEEN EXPOSED!

You shared this API key publicly in chat:
```
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
```

### DO THIS IMMEDIATELY (BEFORE ANYTHING ELSE):

1. **Go to:** https://console.anthropic.com/settings/keys
2. **Find** the key starting with `sk-ant-api03-D32D5on575VA1KLy77VbaM2M...`
3. **Click "Delete"** or **"Revoke"**
4. **Create a NEW API key**
5. **NEVER share API keys again!**

---

# Claude API Implementation - Fixed & Secure

I've updated your project to properly implement the Claude API. Here's what changed:

## ✅ What I Fixed

### 1. **Security Issue**
- ❌ OLD: API calls directly from browser (insecure, won't work)
- ✅ NEW: Backend proxy handles all API calls securely

### 2. **Architecture**
```
BEFORE:                          AFTER:
Browser → Claude API (blocked)   Browser → Backend → Claude API (works!)
         ↓                                ↓
      CORS Error                     Secure & Working
```

### 3. **Files Updated**

- ✅ `backend/server.js` - NEW: Express server with Claude endpoint
- ✅ `backend/package.json` - Updated with all dependencies
- ✅ `frontend/js/ai.js` - Updated to call backend instead
- ✅ `backend/.env.example` - Template for your API key
- ✅ `backend/.gitignore` - Protects secrets from Git

---

# 📦 Setup Instructions

## Step 1: Get a NEW API Key

1. Visit: https://console.anthropic.com/settings/keys
2. Click "Create Key"
3. Copy the key (starts with `sk-ant-...`)
4. **KEEP IT SECRET!** Don't share it anywhere

## Step 2: Configure Backend

```bash
cd backend

# Create .env file from template
cp .env.example .env

# Edit .env and add your NEW API key
# Change this line:
#   ANTHROPIC_API_KEY=your-api-key-here
# To:
#   ANTHROPIC_API_KEY=sk-ant-your-actual-new-key-here
```

**On Windows:**
```cmd
cd backend
copy .env.example .env
notepad .env
```

## Step 3: Install Dependencies

```bash
# Still in backend/ folder
npm install
```

This installs:
- `@anthropic-ai/sdk` - Official Claude SDK
- `express` - Web server
- `cors` - Cross-origin requests
- `dotenv` - Environment variables
- `json-server` - Mock database

## Step 4: Start Backend

```bash
npm start
```

You should see:
```
==================================================
🚀 DHL Knowledge Base Backend Server
==================================================
✅ Server running on http://localhost:3000
📊 JSON Server API: http://localhost:3000/api/articles
🤖 Claude AI Endpoint: http://localhost:3000/api/claude
💚 Health Check: http://localhost:3000/health
==================================================
```

## Step 5: Open Frontend

**Option A - Direct File:**
Just open `frontend/index.html` in your browser

**Option B - Local Server (recommended):**
```bash
# In a NEW terminal, from project root
cd frontend

# Using Python
python -m http.server 8080

# OR using Node.js
npx http-server -p 8080
```

Then visit: `http://localhost:8080`

## Step 6: Test the Integration

1. **Login:** `admin` / `admin123`
2. **Go to:** "Upload Console" (sidebar)
3. **Paste some text**, like:
   ```
   Meeting notes from today:
   - Customer called about delayed shipment
   - Need to check tracking number DHL12345
   - Update customer by EOD
   - Follow up with warehouse team
   ```
4. **Click:** "Generate Draft with AI" button
5. **Wait 2-5 seconds** - Claude will structure it into a proper article!

---

# 🔧 Troubleshooting

## Error: "AI error 401: Unauthorized"

**Problem:** API key is wrong/missing

**Fix:**
1. Check `backend/.env` file exists
2. Make sure your API key is correct
3. No extra spaces or quotes around the key
4. Restart the backend server

## Error: "Failed to fetch" or "Network error"

**Problem:** Backend not running

**Fix:**
```bash
cd backend
npm start
```

## Error: "CORS policy blocked"

**Problem:** Frontend URL doesn't match backend

**Fix:**
- Make sure backend is on port 3000
- Check `frontend/js/ai.js` has: `http://localhost:3000/api/claude`

## Error: "Cannot find module '@anthropic-ai/sdk'"

**Problem:** Dependencies not installed

**Fix:**
```bash
cd backend
npm install
```

## AI response is slow

**This is normal!** Claude takes 2-5 seconds to generate responses.
Just wait and don't click the button multiple times.

---

# 💰 Cost Tracking

Your API usage is billed per token:
- **Input:** ~$3 per million tokens
- **Output:** ~$15 per million tokens

For this KB system:
- Each article ≈ 500-1000 tokens
- Cost per article ≈ $0.01-0.02
- **Very affordable for a university project!**

Monitor usage: https://console.anthropic.com/settings/usage

---

# 🔒 Security Best Practices

✅ **DO:**
- Store API keys in `.env` files
- Add `.env` to `.gitignore`
- Use backend proxy for API calls
- Keep keys secret
- Delete exposed keys immediately

❌ **DON'T:**
- Commit API keys to Git
- Share keys in chat/email
- Put keys in frontend code
- Use same key across projects

---

# 📁 Project Structure (Updated)

```
ai-project/
├── backend/
│   ├── server.js          ← NEW: Express + Claude API proxy
│   ├── package.json       ← UPDATED: Added dependencies
│   ├── .env.example       ← NEW: Template for secrets
│   ├── .env               ← CREATE THIS: Your actual API key
│   ├── .gitignore         ← NEW: Protects secrets
│   ├── db.json            ← Database
│   └── middleware.js      ← Auth middleware
│
├── frontend/
│   ├── js/
│   │   ├── ai.js          ← UPDATED: Now calls backend
│   │   ├── ai.js.backup   ← Your original file (saved)
│   │   └── ...
│   └── ...
│
├── start.sh               ← NEW: Quick start script
└── SETUP_INSTRUCTIONS.md  ← This file
```

---

# 🎯 Quick Commands Reference

```bash
# 1. Setup (first time only)
cd backend
cp .env.example .env
# Edit .env with your API key
npm install

# 2. Start backend (every time)
cd backend
npm start

# 3. Start frontend (optional, for local server)
cd frontend
python -m http.server 8080
# OR
npx http-server -p 8080

# 4. Test API endpoint
curl http://localhost:3000/health
```

---

# ✅ Checklist

Before running:
- [ ] Revoked the exposed API key
- [ ] Created a NEW API key
- [ ] Created `backend/.env` file
- [ ] Added API key to `.env`
- [ ] Ran `npm install` in backend
- [ ] Backend starts without errors
- [ ] Frontend can connect to backend

---

# 🆘 Still Having Issues?

1. **Check backend logs** - Look for error messages in the terminal
2. **Test health endpoint** - Visit `http://localhost:3000/health`
3. **Check browser console** - Press F12, look for errors
4. **Verify API key** - Try it in a simple test first
5. **Check ports** - Make sure 3000 and 8080 aren't in use

---

# 📚 Additional Resources

- **Claude API Docs:** https://docs.anthropic.com
- **API Keys:** https://console.anthropic.com/settings/keys
- **Usage Dashboard:** https://console.anthropic.com/settings/usage
- **SDK Reference:** https://github.com/anthropics/anthropic-sdk-typescript

---

**Ready to start?** Follow Step 1 above! 🚀
