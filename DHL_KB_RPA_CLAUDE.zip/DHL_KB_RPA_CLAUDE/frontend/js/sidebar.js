// sidebar.js — Injects the shared sidebar + auth guard into every page

const SIDEBAR_HTML = `
<aside class="sidebar">
  <div class="sidebar-brand">
    <span class="dhl-logo-sm">DHL</span>
    <span>KB System</span>
  </div>
  <nav class="sidebar-nav">
    <a href="index.html"     class="nav-item" data-page="index">
      <span class="nav-icon">📋</span> Knowledge Base
    </a>
    <a href="upload.html"    class="nav-item" data-page="upload">
      <span class="nav-icon">⬆️</span> Upload Console
    </a>
    <a href="editor.html"    class="nav-item" data-page="editor">
      <span class="nav-icon">✏️</span> Draft Editor
    </a>
    <a href="kb-builder.html" class="nav-item" data-page="kb-builder">
      <span class="nav-icon">🔨</span> KB Builder
    </a>
    <a href="logs.html"      class="nav-item" data-page="logs">
      <span class="nav-icon">🤖</span> RPA Logs
    </a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-badge">
      <span id="userBadgeIcon">👤</span>
      <div>
        <div id="userBadgeName" class="user-name"></div>
        <div id="userBadgeRole" class="user-role"></div>
      </div>
    </div>
    <button class="btn-logout" onclick="doLogout()">Logout</button>
  </div>
</aside>`;

function initSidebar() {
  // Auth guard — redirect to login if not logged in
  const stored = sessionStorage.getItem('currentUser');
  if (!stored) {
    window.location.href = 'login.html';
    return false;
  }

  // Inject sidebar before main content
  const shell = document.getElementById('appShell');
  if (shell) {
    shell.insertAdjacentHTML('afterbegin', SIDEBAR_HTML);
  }

  // Highlight active nav item
  const currentPage = window.location.pathname.split('/').pop().replace('.html','') || 'index';
  document.querySelectorAll('.nav-item').forEach(link => {
    if (link.dataset.page === currentPage) {
      link.classList.add('active');
    }
  });

  // Set user info
  const user = JSON.parse(stored);
  document.getElementById('userBadgeName').textContent = user.username;
  document.getElementById('userBadgeRole').textContent = user.role.toUpperCase();
  document.getElementById('userBadgeIcon').textContent = user.role === 'admin' ? '👑' : '✏️';

  return true;
}

function doLogout() {
  sessionStorage.clear();
  window.location.href = 'login.html';
}

// Run on load
document.addEventListener('DOMContentLoaded', initSidebar);

function getCurrentUser() {
  const stored = sessionStorage.getItem('currentUser');
  return stored ? JSON.parse(stored) : null;
}
