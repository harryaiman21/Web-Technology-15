// ai.js — AI Draft Builder powered by Claude (Anthropic)
// ---------------------------------------------------------------
// Calls backend proxy which securely handles Claude API
// ---------------------------------------------------------------

const BACKEND_AI_URL = 'http://localhost:3000/api/claude';

// ---------------------------------------------------------------
// CORE helper — send a prompt to Claude via backend, get text back
// ---------------------------------------------------------------
async function callClaude(prompt, maxTokens = 1000) {
  const res = await fetch(BACKEND_AI_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, maxTokens })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error('AI error ' + res.status + ': ' + (err?.message || 'Unknown error'));
  }

  const data = await res.json();
  if (!data.success || !data.text) {
    throw new Error('No response from AI');
  }
  
  return data.text;
}

// ---------------------------------------------------------------
// Parse JSON safely — strips markdown fences if present
// ---------------------------------------------------------------
function parseJSON(text) {
  const clean = text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();
  try {
    return JSON.parse(clean);
  } catch {
    const match = clean.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw new Error('AI returned invalid JSON — try again');
  }
}

// ---------------------------------------------------------------
// MAIN: Generate a structured KB article from raw messy input
// ---------------------------------------------------------------
async function aiGenerateDraft(rawInput) {
  const prompt = `You are a DHL Knowledge Base editor. Convert the raw operational input below into a clean, structured Standard Operating Procedure (SOP) article for DHL logistics staff.

The input may come from: Teams/Telegram chats, email threads, handwritten notes, PowerPoint slides, or OCR text from screenshots.

Return ONLY valid JSON — no markdown, no code fences, no extra text:
{
  "title": "Short clear SOP title (max 80 chars)",
  "summary": "1-2 sentence description of what this article covers",
  "steps": [
    "Step 1: ...",
    "Step 2: ...",
    "Step 3: ..."
  ],
  "tags": ["tag1", "tag2", "tag3"],
  "relatedLinks": [],
  "qualityNotes": "Brief note on completeness or anything missing from the input"
}

RAW INPUT:
${rawInput.substring(0, 3000)}`;

  const text = await callClaude(prompt, 1000);
  return parseJSON(text);
}

// ---------------------------------------------------------------
// Conflict checker: compare new draft against published articles
// ---------------------------------------------------------------
async function aiCheckConflicts(newDraft, publishedArticles) {
  if (!publishedArticles.length) return { conflicts: [] };

  const existingSummaries = publishedArticles
    .slice(0, 10)
    .map(a => '[#' + a.id + '] "' + a.title + '": ' + (a.summary || (a.content || '').substring(0, 100)))
    .join('\n');

  const prompt = `You are a DHL Knowledge Base quality checker.

A new draft is being submitted. Check if it DIRECTLY CONTRADICTS or DUPLICATES any existing published article.

NEW DRAFT:
Title: ${newDraft.title}
Content: ${(newDraft.content || '').substring(0, 500)}

EXISTING PUBLISHED ARTICLES:
${existingSummaries}

Return ONLY valid JSON — no markdown:
{
  "conflicts": [
    { "articleId": <number>, "reason": "brief explanation" }
  ]
}

If no real conflicts return: { "conflicts": [] }
Only flag DIRECT contradictions, not just similar topics.`;

  try {
    const text = await callClaude(prompt, 500);
    return parseJSON(text);
  } catch {
    return { conflicts: [] };
  }
}

// ---------------------------------------------------------------
// OCR + AI: structure text extracted from an image
// ---------------------------------------------------------------
async function aiStructureOCRText(ocrText) {
  return aiGenerateDraft('[Text extracted via OCR from an image/screenshot]\n\n' + ocrText);
}
