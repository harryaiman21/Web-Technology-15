// editor.js — Article editor with version history & status promotion
let currentArticleId = null;
let currentArticle = null;

const STATUS_ORDER = ['Draft', 'Reviewed', 'Published'];

async function loadEditor(id) {
  currentArticleId = id;
  try {
    const article = await apiGetArticle(id);
    currentArticle = article;

    document.getElementById('editorTitle').textContent = article.title;
    document.getElementById('editTitle').value = article.title;
    document.getElementById('editSummary').value = article.summary || '';
    document.getElementById('editContent').value = article.content || '';
    document.getElementById('editTags').value = (article.tags || []).join(', ');

    const badge = document.getElementById('editStatusBadge');
    badge.textContent = article.status;
    badge.className = `status-badge status-${article.status}`;

    renderVersionHistory(article.history || []);
    renderMeta(article);
  } catch (e) {
    alert('Failed to load article: ' + e.message);
  }
}

function renderVersionHistory(history) {
  const el = document.getElementById('versionHistory');
  if (!history.length) {
    el.innerHTML = '<div style="color:var(--text-secondary)">No history yet.</div>';
    return;
  }
  el.innerHTML = [...history].reverse().map(h => `
    <div class="version-item">
      <span>v${h.version}</span>
      <span class="status-badge status-${h.status}">${h.status}</span>
      <span style="color:var(--text-secondary);font-size:0.75rem">${formatDate(h.updatedAt)}</span>
    </div>
  `).join('');
}

function renderMeta(article) {
  const el = document.getElementById('articleMeta');
  el.innerHTML = `
    <div class="meta-row"><span class="meta-label">Creator</span><span>${article.creator}</span></div>
    <div class="meta-row"><span class="meta-label">Created</span><span>${formatDate(article.createdAt)}</span></div>
    <div class="meta-row"><span class="meta-label">Updated</span><span>${formatDate(article.updatedAt)}</span></div>
    <div class="meta-row"><span class="meta-label">Version</span><span>v${article.version}</span></div>
    ${article.sourceFile ? `<div class="meta-row"><span class="meta-label">Source</span><span>${article.sourceFile}</span></div>` : ''}
  `;
}

async function saveEdit() {
  if (!currentArticleId) return;
  const now = new Date().toISOString();
  const newVersion = (currentArticle.version || 1) + 1;
  const history = [...(currentArticle.history || []), {
    version: newVersion,
    status: currentArticle.status,
    updatedAt: now
  }];

  const updated = {
    title: document.getElementById('editTitle').value.trim(),
    summary: document.getElementById('editSummary').value.trim(),
    content: document.getElementById('editContent').value.trim(),
    tags: document.getElementById('editTags').value.split(',').map(t => t.trim()).filter(Boolean),
    updatedAt: now,
    version: newVersion,
    history
  };

  try {
    await apiUpdateArticle(currentArticleId, updated);
    currentArticle = { ...currentArticle, ...updated };
    document.getElementById('editorTitle').textContent = updated.title;
    renderVersionHistory(history);
    renderMeta(currentArticle);
    alert('✅ Saved!');
    loadArticles();
  } catch (e) {
    alert('Error saving: ' + e.message);
  }
}

async function promoteStatus() {
  if (!currentArticle) return;
  const idx = STATUS_ORDER.indexOf(currentArticle.status);
  if (idx >= STATUS_ORDER.length - 1) {
    alert('Article is already Published.');
    return;
  }
  const newStatus = STATUS_ORDER[idx + 1];
  const now = new Date().toISOString();
  const history = [...(currentArticle.history || []), {
    version: currentArticle.version,
    status: newStatus,
    updatedAt: now
  }];

  try {
    await apiUpdateArticle(currentArticleId, { status: newStatus, updatedAt: now, history });
    currentArticle.status = newStatus;
    currentArticle.history = history;

    const badge = document.getElementById('editStatusBadge');
    badge.textContent = newStatus;
    badge.className = `status-badge status-${newStatus}`;
    renderVersionHistory(history);
    loadArticles();
    alert(`✅ Status promoted to ${newStatus}`);
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

async function deleteArticle() {
  if (!currentArticleId) return;
  if (!confirm(`Delete "${currentArticle.title}"? This cannot be undone.`)) return;
  try {
    await apiDeleteArticle(currentArticleId);
    await loadArticles();
    showPage('viewer');
  } catch (e) {
    alert('Error deleting: ' + e.message);
  }
}

function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-MY', { day:'2-digit', month:'short', year:'numeric' });
}
