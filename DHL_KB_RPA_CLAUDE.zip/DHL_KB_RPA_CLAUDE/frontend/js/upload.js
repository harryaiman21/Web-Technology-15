// upload.js — Upload Console logic
let attachedFileName = null;
let attachedFileContent = null;

function onDragOver(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.add('drag-over');
}

function onDrop(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
}

function onFileSelect(e) {
  const file = e.target.files[0];
  if (file) handleFile(file);
}

function handleFile(file) {
  const allowed = ['text/plain', 'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/png', 'image/jpeg'];
  const ext = file.name.split('.').pop().toLowerCase();
  const allowedExts = ['txt','pdf','docx','png','jpg','jpeg'];

  if (!allowedExts.includes(ext)) {
    showUploadMsg('❌ Unsupported file type. Use .txt, .pdf, .docx, .png, or .jpg', 'error');
    return;
  }

  attachedFileName = file.name;
  const preview = document.getElementById('filePreview');
  preview.style.display = 'block';
  preview.innerHTML = `<strong>📎 ${escHtml(file.name)}</strong><br/>
    <small>${(file.size/1024).toFixed(1)} KB · ${ext.toUpperCase()}</small>`;

  // For txt files, read content to populate textarea
  if (ext === 'txt') {
    const reader = new FileReader();
    reader.onload = (ev) => {
      attachedFileContent = ev.target.result;
      if (!document.getElementById('uploadContent').value) {
        document.getElementById('uploadContent').value = ev.target.result.substring(0, 2000);
      }
    };
    reader.readAsText(file);
  } else {
    attachedFileContent = `[Attached: ${file.name}]`;
  }
}

async function submitArticle() {
  const title = document.getElementById('uploadTitle').value.trim();
  const content = document.getElementById('uploadContent').value.trim();
  const tagsRaw = document.getElementById('uploadTags').value.trim();
  const status = document.getElementById('saveStatus').value;
  const user = getCurrentUser();

  if (!title) { showUploadMsg('❌ Title is required.', 'error'); return; }
  if (!content && !attachedFileContent) { showUploadMsg('❌ Please enter content or attach a file.', 'error'); return; }

  const finalContent = content || attachedFileContent || '';
  const hash = simpleHash(title + finalContent);

  // Duplicate check: same hash in last 14 days
  const articles = await apiGetArticles();
  const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();
  const dup = articles.find(a => a.hash === hash && a.createdAt > cutoff);
  if (dup) {
    showUploadMsg(`⚠️ Duplicate detected! This content matches article #${dup.id} created within the last 14 days.`, 'error');
    return;
  }

  // AI Conflict check against published articles
  try {
    const published = articles.filter(a => a.status === 'Published');
    if (published.length > 0) {
      const { conflicts } = await aiCheckConflicts({ title, content: finalContent }, published);
      if (conflicts && conflicts.length > 0) {
        const c = conflicts[0];
        const proceed = confirm(
          `⚠️ AI Conflict Alert!\n\nThis article may conflict with Article #${c.articleId}.\nReason: ${c.reason}\n\nSave anyway?`
        );
        if (!proceed) {
          showUploadMsg('❌ Save cancelled due to conflict.', 'error');
          return;
        }
      }
    }
  } catch (e) {
    // Conflict check failed silently — don't block saving
    console.warn('Conflict check skipped:', e.message);
  }

  // Build article
  const tags = tagsRaw ? tagsRaw.split(',').map(t => t.trim()).filter(Boolean) : [];
  const now = new Date().toISOString();
  const summary = finalContent.substring(0, 120) + (finalContent.length > 120 ? '...' : '');

  const newArticle = {
    title,
    summary,
    content: finalContent,
    tags,
    status,
    creator: user ? user.username : 'unknown',
    createdAt: now,
    updatedAt: now,
    version: 1,
    history: [{ version: 1, status, updatedAt: now }],
    sourceFile: attachedFileName,
    hash
  };

  try {
    await apiCreateArticle(newArticle);
    showUploadMsg('✅ Article saved successfully!', 'success');
    // Reset form
    document.getElementById('uploadTitle').value = '';
    document.getElementById('uploadContent').value = '';
    document.getElementById('uploadTags').value = '';
    document.getElementById('filePreview').style.display = 'none';
    attachedFileName = null;
    attachedFileContent = null;
    // Reload articles in background
    // Redirect back after save
    setTimeout(() => { window.location.href = "index.html"; }, 1500);
  } catch (e) {
    showUploadMsg(`❌ Error: ${e.message}`, 'error');
  }
}

function showUploadMsg(msg, type) {
  const el = document.getElementById('uploadMsg');
  el.className = `msg-box msg-${type}`;
  el.innerHTML = msg;
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 5000);
}

function escHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ============================================================
// AI INTEGRATION
// ============================================================
let _aiDraft = null; // holds the AI result until user applies it

async function aiAutoFill() {
  const raw = document.getElementById('uploadContent').value.trim();
  if (!raw) {
    showAIStatus('❌ Paste some raw content first, then click Generate.', 'error');
    return;
  }

  const btn = document.getElementById('aiBtn');
  btn.disabled = true;
  btn.textContent = '⏳ AI is thinking...';
  showAIStatus('🤖 Sending to Gemini AI — usually takes 3-5 seconds...', 'loading');
  document.getElementById('aiResultPanel').style.display = 'none';

  try {
    const draft = await aiGenerateDraft(raw);
    _aiDraft = draft;

    // Show steps preview
    const stepsHtml = draft.steps && draft.steps.length
      ? '<strong>Proposed Steps:</strong><ol style="margin:0.5rem 0 0 1rem">' +
        draft.steps.map(s => `<li>${escHtml(s)}</li>`).join('') + '</ol>'
      : '<em>No steps extracted</em>';

    document.getElementById('aiStepsPreview').innerHTML =
      `<strong>Title:</strong> ${escHtml(draft.title)}<br/>` +
      `<strong>Summary:</strong> ${escHtml(draft.summary)}<br/>` +
      `<strong>Tags:</strong> ${(draft.tags || []).map(t => `<span style="background:rgba(255,204,0,0.15);color:var(--dhl-yellow);padding:0.1em 0.4em;border-radius:4px;font-size:0.75rem;margin-right:0.3rem">${escHtml(t)}</span>`).join('')}<br/><br/>` +
      stepsHtml;

    if (draft.qualityNotes) {
      document.getElementById('aiQualityNote').textContent = '💡 ' + draft.qualityNotes;
      document.getElementById('aiQualityNote').style.display = 'block';
    } else {
      document.getElementById('aiQualityNote').style.display = 'none';
    }

    document.getElementById('aiResultPanel').style.display = 'block';
    showAIStatus('✅ AI draft ready — review and apply.', 'success');
  } catch (e) {
    showAIStatus(`❌ ${e.message}`, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '✨ Generate with AI';
  }
}

function applyAIDraft() {
  if (!_aiDraft) return;

  document.getElementById('uploadTitle').value = _aiDraft.title || '';
  document.getElementById('uploadTags').value = (_aiDraft.tags || []).join(', ');

  // Build structured content from steps
  const parts = [];
  if (_aiDraft.summary) parts.push(_aiDraft.summary);
  if (_aiDraft.steps && _aiDraft.steps.length) {
    parts.push('\nSteps:\n' + _aiDraft.steps.map((s, i) => `${i + 1}. ${s}`).join('\n'));
  }
  if (parts.length) {
    document.getElementById('uploadContent').value = parts.join('\n');
  }

  document.getElementById('aiResultPanel').style.display = 'none';
  showAIStatus('✅ AI draft applied — review and save.', 'success');
  _aiDraft = null;
}

function dismissAI() {
  document.getElementById('aiResultPanel').style.display = 'none';
  document.getElementById('aiStatus').style.display = 'none';
  _aiDraft = null;
}

function showAIStatus(msg, type) {
  const el = document.getElementById('aiStatus');
  const colors = {
    error:   'background:rgba(212,5,17,0.12);color:#ff6b6b;border:1px solid rgba(212,5,17,0.25)',
    success: 'background:rgba(46,204,113,0.12);color:#2ecc71;border:1px solid rgba(46,204,113,0.25)',
    loading: 'background:rgba(255,204,0,0.08);color:var(--dhl-yellow);border:1px solid rgba(255,204,0,0.2)'
  };
  el.style.cssText = (colors[type] || colors.loading) + ';padding:0.5rem 0.75rem;border-radius:8px;font-size:0.78rem';
  el.textContent = msg;
  el.style.display = 'block';
  if (type !== 'loading') setTimeout(() => { el.style.display = 'none'; }, 6000);
}
