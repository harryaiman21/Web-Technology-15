// app.js — Page routing and app initialization

function showPage(pageName) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  // Show target
  const target = document.getElementById(`page-${pageName}`);
  if (target) target.classList.add('active');

  // Update nav active state
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const navMap = { viewer: 0, upload: 1, editor: 2, logs: 3 };
  const idx = navMap[pageName];
  const navItems = document.querySelectorAll('.nav-item');
  if (idx !== undefined && navItems[idx]) navItems[idx].classList.add('active');

  // Page-specific init
  if (pageName === 'viewer') {
    filterArticles(); // re-apply current filters
  }
  if (pageName === 'logs') {
    loadLogs();
  }
}
