// auth.js — Login / Logout logic
let currentUser = null;

// On page load, check if user is already logged in
document.addEventListener('DOMContentLoaded', () => {
  const stored = sessionStorage.getItem('currentUser');
  if (stored) {
    const user = JSON.parse(stored);
    currentUser = user;
    applySession(user);
  }

  document.getElementById('loginPass').addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
});

async function doLogin() {
  const username = document.getElementById('loginUser').value.trim();
  const password = document.getElementById('loginPass').value.trim();
  const errEl = document.getElementById('loginError');

  if (!username || !password) {
    errEl.textContent = 'Please enter username and password.';
    errEl.style.display = 'block';
    return;
  }

  try {
    const users = await apiGetUsers();
    const user = users.find(u => u.username === username && u.password === password);
    if (!user) {
      errEl.textContent = 'Invalid username or password.';
      errEl.style.display = 'block';
      return;
    }

    currentUser = user;
    sessionStorage.setItem('authToken', btoa(`${user.username}:${user.role}`));
    sessionStorage.setItem('currentUser', JSON.stringify(user));
    errEl.style.display = 'none';
    applySession(user);
  } catch (e) {
    errEl.textContent = 'Server error. Make sure JSON Server is running on port 3001.';
    errEl.style.display = 'block';
  }
}

function applySession(user) {
  document.getElementById('userBadgeName').textContent = user.username;
  document.getElementById('userBadgeRole').textContent = user.role.toUpperCase();
  document.getElementById('userBadgeIcon').textContent = user.role === 'admin' ? '👑' : '✏️';

  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('appShell').style.display = 'flex';

  showPage('viewer');
  loadArticles();
}

function doLogout() {
  currentUser = null;
  sessionStorage.clear();
  document.getElementById('loginScreen').style.display = 'flex';
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('loginUser').value = '';
  document.getElementById('loginPass').value = '';
}

function getCurrentUser() {
  if (currentUser) return currentUser;
  const stored = sessionStorage.getItem('currentUser');
  return stored ? JSON.parse(stored) : null;
}
