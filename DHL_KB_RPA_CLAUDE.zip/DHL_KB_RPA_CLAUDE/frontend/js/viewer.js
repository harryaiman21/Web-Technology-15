// viewer.js — Knowledge Base viewer with search, filter, sort
let allArticles = [];

async function loadArticles() {
  try {
    allArticles = await apiGetArticles();
    populateTagFilter();
    renderArticles(allArticles);
  } catch (e) {
    document.getElementById('articleGrid').innerHTML =
      `<div style="color:var(--danger);padding:1rem;">⚠️ Could not load articles. Is JSON Server running?<br/><small>${e.message}</small></div>`;
  }
}

function populateTagFilter() {
  const allTags = new Set();
  allArticles.forEach(a => (a.tags || []).forEach(t => allTags.add(t)));
  const sel = document.getElementById('filterTag');
  sel.innerHTML = '<option value="">All Tags</option>';
  [...allTags].sort().forEach(tag => {
    const opt = document.createElement('option');
    opt.value = tag;
    opt.textContent = tag;
    sel.appendChild(opt);
  });
}

function filterArticles() {
  const query = document.getElementById('searchInput').value.toLowerCase();
  const status = document.getElementById('filterStatus').value;
  const tag = document.getElementById('filterTag').value;
  const date = document.getElementById('filterDate').value;

  const filtered = allArticles.filter(a => {
    const matchText = !query ||
      a.title.toLowerCase().includes(query) ||
      (a.summary || '').toLowerCase().includes(query) ||
      (a.content || '').toLowerCase().includes(query);

    const matchStatus = !status || a.status === status;
    const matchTag = !tag || (a.tags || []).includes(tag);
    const matchDate = !date || a.createdAt.startsWith(date);

    return matchText && matchStatus && matchTag && matchDate;
  });

  renderArticles(filtered);
}

function renderArticles(articles) {
  const grid = document.getElementById('articleGrid');
  if (!articles.length) {
    grid.innerHTML = '<div style="color:var(--text-secondary);padding:1rem;">No articles found.</div>';
    return;
  }

  grid.innerHTML = articles.map(a => `
    <div class="article-card" onclick="openArticle(${a.id})">
      <div class="article-card-header">
        <h3>${escHtml(a.title)}</h3>
        <span class="status-badge status-${a.status}">${a.status}</span>
      </div>
      <p class="article-summary">${escHtml(a.summary || '')}</p>
      <div class="article-tags">
        ${(a.tags || []).map(t => `<span class="tag">${escHtml(t)}</span>`).join('')}
      </div>
      <div class="article-meta">
        <span>👤 ${escHtml(a.creator)}</span>
        <span>📅 ${formatDate(a.updatedAt)}</span>
        <span>v${a.version}</span>
      </div>
    </div>
  `).join('');
}

function openArticle(id) {
  loadEditor(id);
  showPage('editor');
}

function escHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-MY', { day:'2-digit', month:'short', year:'numeric' });
}
