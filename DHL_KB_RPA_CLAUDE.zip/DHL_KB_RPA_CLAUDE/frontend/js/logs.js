// logs.js — RPA Activity Logs viewer
async function loadLogs() {
  const el = document.getElementById('logsTable');
  try {
    const logs = await apiGetLogs();
    if (!logs.length) {
      el.innerHTML = '<div style="padding:1.5rem;color:var(--text-secondary)">No RPA logs yet.</div>';
      return;
    }

    const rows = logs.map(l => `
      <div class="log-row">
        <span>${new Date(l.timestamp).toLocaleString('en-MY')}</span>
        <span>${l.action}</span>
        <span>${l.articleId ? '#' + l.articleId : '—'}</span>
        <span>${l.details}</span>
        <span class="log-${l.status}">${l.status === 'success' ? '✅ OK' : '❌ Fail'}</span>
      </div>
    `).join('');

    el.innerHTML = `
      <div class="log-row header">
        <span>Timestamp</span>
        <span>Action</span>
        <span>Article</span>
        <span>Details</span>
        <span>Status</span>
      </div>
      ${rows}
    `;
  } catch (e) {
    el.innerHTML = `<div style="padding:1.5rem;color:var(--danger)">⚠️ Failed to load logs: ${e.message}</div>`;
  }
}
