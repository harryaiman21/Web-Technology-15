# DHL KB RPA Workflow — UiPath Studio Documentation
# File: uipath-docs/RPA_Workflow_Explained.md

## Overview

This document explains the full UiPath RPA automation workflow for the 
DHL Knowledge Base System. The robot monitors a Google Drive folder, 
reads new files, creates KB articles via the web API, and emails a 
summary report to the admin.

---

## Trigger

- **Type**: Scheduled / Time-based trigger (or Orchestrator queue)
- **Schedule**: Daily at 08:00 AM (configurable in UiPath Orchestrator)
- **Alternatively**: Folder watch trigger (UiPath Integration Service → Google Drive)

---

## Workflow File Structure (UiPath Project)

```
DHL_KB_RPA/
├── Main.xaml               ← Entry point
├── Workflows/
│   ├── ReadGoogleDrive.xaml
│   ├── DuplicateCheck.xaml
│   ├── CreateArticleAPI.xaml
│   ├── UpdateStatusAPI.xaml
│   ├── SendSummaryEmail.xaml
│   └── ErrorHandler.xaml
├── Data/
│   ├── processed_hashes.json   ← Local hash registry (last 14 days)
│   └── run_log.txt
└── project.json
```

---

## Step-by-Step Automation Logic

### STEP 1 — Initialize Run

**Sequence: Main.xaml**

```
[Assign] runStats = { created: 0, updated: 0, duplicates: 0, failed: 0 }
[Assign] runTimestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
[Assign] logMessages = New List(Of String)
[Log Message] "RPA Run Started: " + runTimestamp
```

---

### STEP 2 — Read Files from Google Drive

**Sequence: ReadGoogleDrive.xaml**

**Required UiPath Packages:**
- UiPath.GSuite.Activities (Google Drive)

```
[Google Drive] List Files
    → FolderPath = "DHL/KB_Inbox"
    → Filter = "modifiedTime > '2 days ago'"
    → Output → driveFiles (List of DriveFile)

[If] driveFiles.Count = 0
    → [Log Message] "No new files found. Exiting."
    → GOTO SendSummaryEmail
```

**Files supported:** .txt, .pdf, .docx, .png, .jpg

---

### STEP 3 — Loop Through Each File

**For Each: file In driveFiles**

```
[Try]
    [Google Drive] Download File
        → FileId = file.Id
        → SavePath = "C:\RPA_Temp\" + file.Name

    [Assign] rawText = ""

    [Switch on file extension]
        .txt  → [Read Text File] rawText = File.ReadAllText(path)
        .pdf  → [Use Activity: Read PDF Text] rawText = pdfText
        .docx → [Use Activity: Read DOCX] rawText = docxText
        .png/.jpg → rawText = "[Image file: " + file.Name + "]"
              (Optional: Use OCR - UiPath.Core.Activities → Get OCR Text)

    [Invoke Workflow] DuplicateCheck.xaml
        → In: rawText, file.Name
        → Out: isDuplicate (Boolean)

    [If] isDuplicate = True
        → [Log] "DUPLICATE: " + file.Name
        → runStats.duplicates += 1
        → CONTINUE (next file)

    [Invoke Workflow] CreateArticleAPI.xaml
        → In: rawText, file.Name
        → Out: articleId (Integer), success (Boolean)

    [If] success = True
        → runStats.created += 1
        → [Invoke Workflow] UpdateStatusAPI.xaml
            → In: articleId, newStatus = "Draft"

[Catch Exception ex]
    [Log Message] "ERROR processing " + file.Name + ": " + ex.Message
    [Take Screenshot] → Save to C:\RPA_Temp\error_screenshots\
    [Assign] runStats.failed += 1
    [Add to logMessages] "FAILED: " + file.Name + " | " + ex.Message
```

---

### STEP 4 — Duplicate Check

**Workflow: DuplicateCheck.xaml**

```
[Assign] hash = ComputeHash(rawText + fileName)
    (Use: System.Security.Cryptography.MD5)

[Read JSON File] processedHashes = "Data/processed_hashes.json"
    → Deserialize to Dictionary(String, DateTime)

[Assign] cutoffDate = DateTime.Now.AddDays(-14)

[Filter] recentHashes = processedHashes
    .Where(Function(kvp) kvp.Value > cutoffDate)
    .ToDictionary(...)

[If] recentHashes.ContainsKey(hash)
    → isDuplicate = True
[Else]
    → isDuplicate = False
    → recentHashes.Add(hash, DateTime.Now)
    → [Write JSON File] save updated hashes back

[Output] isDuplicate
```

---

### STEP 5 — Create Article via API

**Workflow: CreateArticleAPI.xaml**

```
[Assign] apiUrl = "http://localhost:3001/articles"

[Assign] articleTitle = ExtractTitle(rawText)
    → Use first non-empty line, max 80 chars

[Assign] summary = rawText.Substring(0, Math.Min(120, rawText.Length)) + "..."

[Assign] tags = AutoTag(rawText)
    → Simple keyword matching:
       "delivery" → "delivery", "SOP" → "SOP",
       "address" → "address", "damage" → "damage", etc.

[Assign] requestBody = New JObject({
    title    = articleTitle,
    summary  = summary,
    content  = rawText,
    tags     = New JArray(tags),
    status   = "Draft",
    creator  = "RPA_BOT",
    createdAt = DateTime.UtcNow.ToString("o"),
    updatedAt = DateTime.UtcNow.ToString("o"),
    version   = 1,
    history   = New JArray(New JObject({
        version   = 1,
        status    = "Draft",
        updatedAt = DateTime.UtcNow.ToString("o")
    })),
    sourceFile = fileName,
    hash       = hash
})

[HTTP Request]
    → Method: POST
    → URL: apiUrl
    → Headers: Content-Type: application/json
               X-Api-Key: RPA_SECRET_KEY_DHL_2026
    → Body: requestBody.ToString()
    → Output: responseBody

[Deserialize JSON] response = JObject.Parse(responseBody)
[Assign] articleId = CInt(response("id"))
[Assign] success = (articleId > 0)
```

---

### STEP 6 — Update Article Status

**Workflow: UpdateStatusAPI.xaml**

```
[Assign] patchUrl = "http://localhost:3001/articles/" + articleId.ToString()

[Assign] patchBody = New JObject({
    status    = "Draft",
    updatedAt = DateTime.UtcNow.ToString("o")
})

[HTTP Request]
    → Method: PATCH
    → URL: patchUrl
    → Headers: Content-Type: application/json
               X-Api-Key: RPA_SECRET_KEY_DHL_2026
    → Body: patchBody.ToString()
```

---

### STEP 7 — Send Summary Email

**Workflow: SendSummaryEmail.xaml**

**Required Package:** UiPath.Mail.Activities (SMTP)

```
[Assign] emailBody = String.Format("
DHL KB RPA — Daily Run Summary
================================
Run Time   : {0}
Created    : {1}
Updated    : {2}
Duplicates : {3}
Failed     : {4}

Detailed Log:
{5}
", runTimestamp, runStats.created, runStats.updated,
   runStats.duplicates, runStats.failed,
   String.Join(Environment.NewLine, logMessages))

[Send SMTP Mail Message]
    → To      : admin@dhl.com
    → Subject : "RPA KB Run Summary — " + runTimestamp
    → Body    : emailBody
    → Attachments: "C:\RPA_Temp\run_log.txt"
    → SMTP Server: smtp.gmail.com (or office365)
    → Port: 587, SSL: True

[Log Message] "Summary email sent. Run complete."
```

---

## UiPath Packages Required

Install these from UiPath Studio → Manage Packages:

| Package | Version | Purpose |
|---|---|---|
| UiPath.System.Activities | Latest | Core sequences, variables, loops |
| UiPath.UIAutomation.Activities | Latest | Browser/UI automation (if needed) |
| UiPath.Web.Activities | Latest | HTTP Request for API calls |
| UiPath.Mail.Activities | Latest | Send summary email (SMTP) |
| UiPath.GSuite.Activities | Latest | Google Drive integration |
| UiPath.PDF.Activities | Latest | Read PDF text |
| UiPath.Word.Activities | Latest | Read DOCX text |
| Newtonsoft.Json | Latest | JSON serialize/deserialize |

---

## Workflow Diagram Summary

```
START
  ↓
Initialize Stats & Log
  ↓
List Google Drive Files (DHL/KB_Inbox)
  ↓
[Loop] For Each File
  ├─ Download File to Temp
  ├─ Extract Text (txt/pdf/docx/image)
  ├─ [Duplicate Check] → Hash + 14-day window
  │     ├── YES → Skip + log duplicate
  │     └── NO  → Continue
  ├─ POST to /articles API (create Draft)
  ├─ PATCH to /articles/:id (confirm status)
  └─ [On Error] Screenshot + log failure
  ↓
Send Summary Email to admin@dhl.com
  ↓
END
```

---

## Setting Up UiPath Studio

1. Download UiPath Studio Community Edition (free):
   → https://www.uipath.com/start-trial

2. Install required packages (Manage Packages → Official)

3. Create new Process project: "DHL_KB_RPA"

4. Create workflows as described above

5. Set config variables in a Config.xlsx or in project.json:
   - API_BASE_URL = http://localhost:3001
   - API_KEY = RPA_SECRET_KEY_DHL_2026
   - GOOGLE_DRIVE_FOLDER = DHL/KB_Inbox
   - ADMIN_EMAIL = admin@dhl.com
   - SMTP_SERVER = smtp.gmail.com

6. Connect to Google Drive via UiPath Integration Service

7. Schedule in UiPath Orchestrator (or run manually for demo)

---

## For Demo / Presentation

If Google Drive integration is unavailable, simulate by:
1. Place .txt test files in a local folder C:\RPA_Demo\
2. Replace Google Drive step with "Read Files from Folder" activity
3. The rest of the logic remains identical

This demonstrates full RPA automation thinking even without cloud access.
