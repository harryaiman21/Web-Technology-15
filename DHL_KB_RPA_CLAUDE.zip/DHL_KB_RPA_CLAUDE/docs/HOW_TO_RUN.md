# Step-by-Step Instructions to Run the DHL KB System

**Assignment:** SECJ 3483 Web Technology — Individual Assignment  
**System:** Web Application + JSON API + RPA

---

## Prerequisites

Make sure the following are installed:

| Software | Version | Download |
|---|---|---|
| Node.js | 18+ | https://nodejs.org |
| npm | Included with Node | — |
| UiPath Studio | Community | https://uipath.com |
| Any modern browser | Chrome / Edge | — |

---

## PART 1: Start the Backend (JSON Server)

1. Open a terminal / command prompt
2. Navigate to the `backend/` folder:
   ```
   cd dhl-kb-system/backend
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the JSON Server:
   ```
   npm start
   ```
5. You should see:
   ```
   Resources:  http://localhost:3001/articles
               http://localhost:3001/users
               http://localhost:3001/logs
   ```
6. **Leave this terminal open.** The server must run throughout.

---

## PART 2: Start the Frontend Web Application

1. Open a new terminal
2. Navigate to the `frontend/` folder:
   ```
   cd dhl-kb-system/frontend
   ```
3. Option A — Open directly in browser:
   - Double-click `index.html`  
   - OR drag it into Chrome/Edge

4. Option B — Serve with live-server (recommended):
   ```
   npx live-server --port=5500
   ```

5. The app opens at `http://localhost:5500`

---

## PART 3: Login to the Web App

Use one of these demo accounts:

| Username | Password | Role |
|---|---|---|
| admin | admin123 | Admin (full access) |
| editor1 | editor123 | Editor |
| editor2 | editor123 | Editor |

---

## PART 4: Using the Web Application

### Viewing Articles
- Click **"Knowledge Base"** in the sidebar
- Use the search bar to search by keyword
- Filter by Status, Tag, or Date
- Click any article card to open and edit it

### Creating a New Article
- Click **"Upload Console"**
- Type or paste raw content (chat logs, notes, etc.)
- Optionally attach a .txt, .pdf, .docx, or image file
- Select save status (Draft / Reviewed / Published)
- Click **"Save Article"**

### Editing an Article
- Click any article from the Knowledge Base view
- Modify title, summary, content, or tags
- Click **"Save Changes"**
- Click **"Promote Status"** to move Draft → Reviewed → Published

### Viewing RPA Logs
- Click **"RPA Logs"** in the sidebar
- See all automated actions performed by the RPA bot

---

## PART 5: Running the RPA (UiPath Studio)

### Setup

1. Open UiPath Studio Community Edition
2. Create a new **Process** project named "DHL_KB_RPA"
3. Install required packages via **Manage Packages → Official**:
   - UiPath.Web.Activities
   - UiPath.Mail.Activities
   - UiPath.GSuite.Activities
   - UiPath.PDF.Activities
   - UiPath.Word.Activities

4. Create workflow files as described in `uipath-docs/RPA_Workflow_Explained.md`

### Configure

Set these values in your workflow variables or a Config.xlsx:
```
API_BASE_URL  = http://localhost:3001
API_KEY       = RPA_SECRET_KEY_DHL_2026
ADMIN_EMAIL   = your-email@gmail.com
SMTP_SERVER   = smtp.gmail.com
```

### Demo Run (Without Google Drive)

To demo RPA without cloud access:
1. Create a folder: `C:\RPA_Demo\`
2. Place test `.txt` files inside it
3. In ReadGoogleDrive.xaml, replace the Google Drive activity with  
   **"Read Files from Folder"** activity pointing to `C:\RPA_Demo\`
4. Run Main.xaml from UiPath Studio (F5 or Run button)

### What the RPA Does

1. Reads files from Google Drive / local folder
2. Extracts text from each file
3. Checks for duplicates (14-day hash window)
4. POSTs new article to `/articles` API (status = Draft)
5. On error: takes screenshot, logs failure
6. Sends summary email with totals and log attachment

---

## PART 6: Verify Everything is Working

| Test | How to Verify |
|---|---|
| API GET | Visit http://localhost:3001/articles in browser |
| API POST | Use Upload Console to create article, check it appears |
| API PATCH | Edit article, verify version increments |
| API DELETE | Delete article from editor, verify it disappears |
| Duplicate check | Upload same content twice within 14 days |
| Status flow | Create Draft → Promote to Reviewed → Promote to Published |
| RPA log | After RPA run, check RPA Logs tab in web app |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Cannot connect to API" | Make sure JSON Server is running (`npm start` in backend/) |
| Login fails | Check db.json has users array with correct passwords |
| CORS error in browser | Use `npx live-server` instead of opening file directly |
| RPA HTTP error 401 | Check X-Api-Key header matches middleware.js key |
| Port 3001 in use | Change port in package.json and api.js |

---

## Submission Checklist

- [ ] ZIP file named: `WT_Assignment_<MatricNo>_<Name>.zip`
- [ ] `frontend/` folder with all web files
- [ ] `backend/db.json` with data
- [ ] `uipath-docs/` with RPA workflow files
- [ ] This instructions document
- [ ] Report (8–12 pages)
- [ ] Demo video link (5–10 minutes)
