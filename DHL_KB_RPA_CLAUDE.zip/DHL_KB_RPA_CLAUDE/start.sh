#!/bin/bash

echo "=================================================="
echo "🚀 DHL Knowledge Base - Quick Start"
echo "=================================================="
echo ""

# Check if .env exists
if [ ! -f backend/.env ]; then
    echo "⚠️  No .env file found!"
    echo ""
    echo "Creating .env file from template..."
    cp backend/.env.example backend/.env
    echo ""
    echo "⚠️  IMPORTANT: Edit backend/.env and add your Claude API key!"
    echo "   Get your key from: https://console.anthropic.com/settings/keys"
    echo ""
    echo "Press Enter to continue after you've added your API key..."
    read
fi

# Navigate to backend
cd backend

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing backend dependencies..."
    npm install
    echo ""
fi

# Start the server
echo "✅ Starting backend server..."
echo ""
npm start
