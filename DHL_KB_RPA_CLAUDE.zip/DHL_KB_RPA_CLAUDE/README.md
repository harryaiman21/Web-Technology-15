# DHL Knowledge Base System
## SECJ 3483 Web Technology — Individual Assignment

**Scenario 1: AI-Powered Knowledge Base Automation for DHL Logistics Operations**

---

## Project Structure

```
dhl-kb-system/
├── frontend/              ← Web Application (HTML/CSS/JS)
│   ├── index.html         ← Main app (login + all pages)
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── api.js         ← All API fetch calls (GET/POST/PATCH/DELETE)
│       ├── auth.js        ← Login / Logout
│       ├── viewer.js      ← KB viewer with search & filter
│       ├── upload.js      ← Upload Console (file + text input)
│       ├── editor.js      ← Article editor + version history
│       ├── logs.js        ← RPA logs viewer
│       └── app.js         ← Page routing
├── backend/               ← JSON Server Mock API
│   ├── db.json            ← Database (articles, users, logs)
│   ├── middleware.js      ← Auth middleware
│   └── package.json
├── uipath-docs/           ← RPA Workflow Documentation
│   ├── RPA_Workflow_Explained.md
│   └── Main.xaml
└── docs/
    └── HOW_TO_RUN.md      ← Step-by-step run instructions
```

## Quick Start

```bash
# 1. Start backend
cd backend && npm install && npm start

# 2. Open frontend/index.html in browser
# Login: admin / admin123

# 3. See docs/HOW_TO_RUN.md for full instructions
```

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | /articles | Get all KB articles |
| GET | /articles/:id | Get single article |
| POST | /articles | Create new article |
| PATCH | /articles/:id | Update article |
| DELETE | /articles/:id | Delete article |
| GET | /users | Get all users |
| GET | /logs | Get RPA logs |
| POST | /logs | Create log entry |

## Marking Criteria Covered

- ✅ A1: Knowledge Base Workflow & Business Logic (Draft→Reviewed→Published)
- ✅ A2: User Interface & Interaction (sidebar navigation, responsive layout)
- ✅ A3: JavaScript Functionality (event handling, validation, dynamic rendering)
- ✅ A4: Data Management (search, filter by status/tag/date, sort)
- ✅ A5: JSON & API Integration (full CRUD via JSON Server)
- ✅ B1: RPA Process Identification (documented in RPA_Workflow_Explained.md)
- ✅ B2: RPA Workflow Design (step-by-step with error paths)
- ✅ B3: Automation Logic & Trigger (ingestion, duplicate check, email)
- ✅ B4: RPA Integration (API calls with X-Api-Key, status updates, logs)
