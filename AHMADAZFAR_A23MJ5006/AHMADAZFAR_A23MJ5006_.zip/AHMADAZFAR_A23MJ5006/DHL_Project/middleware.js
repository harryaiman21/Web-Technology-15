module.exports = (req, res, next) => {
    // Increase body size limit to 10MB to support base64 file uploads
    req.express = req.express || {};
    next();
}