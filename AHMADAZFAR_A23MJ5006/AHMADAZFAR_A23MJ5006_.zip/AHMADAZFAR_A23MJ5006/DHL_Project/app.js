const API_URL = "http://localhost:3000/incidents";

// ==========================================
// 1. SECURITY & SESSION MANAGEMENT
// ==========================================
const currentUser = JSON.parse(localStorage.getItem('dhl_user'));

if (!currentUser) {
    window.location.href = 'login.html';
}

// Set User Display and Avatar Initials
document.getElementById('userDisplay').innerText = `${currentUser.username} (${currentUser.role})`;
document.getElementById('userAvatar').innerText = currentUser.username.charAt(0).toUpperCase();

function logout() {
    localStorage.removeItem('dhl_user');
    window.location.href = 'login.html';
}

// ==========================================
// 2. VIEW ROUTING, MODALS & UI TOGGLING
// ==========================================
function switchView(view) {
    const incidentView = document.getElementById('incidentView');
    const analyticsView = document.getElementById('analyticsView');
    const navIncidents = document.getElementById('navIncidents');
    const navAnalytics = document.getElementById('navAnalytics');
    const pageTitle = document.getElementById('pageTitle');

    if (view === 'incidents') {
        incidentView.classList.remove('hidden-view');
        analyticsView.classList.remove('active-view');
        navIncidents.classList.add('active');
        navAnalytics.classList.remove('active');
        pageTitle.textContent = 'Incident Management';
    } else {
        incidentView.classList.add('hidden-view');
        analyticsView.classList.add('active-view');
        navIncidents.classList.remove('active');
        navAnalytics.classList.add('active');
        pageTitle.textContent = 'System Analytics';
        updateAnalytics();
    }
}

// Modal Logic for Creation
function openCreateModal() {
    document.getElementById('createModal').classList.add('open');
}

function closeCreateModal() {
    document.getElementById('createModal').classList.remove('open');
    setTimeout(() => {
        document.getElementById('incidentForm').reset();
        resetFileUploadUI(); // <--- Add this line!
    }, 200);
}

// Drawer Logic for Viewing Details
function openDetailsPanel() {
    document.getElementById('drawerOverlay').classList.add('open');
    document.getElementById('detailDrawer').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeDetailsPanel() {
    document.getElementById('drawerOverlay').classList.remove('open');
    document.getElementById('detailDrawer').classList.remove('open');
    document.body.style.overflow = '';
}

// ==========================================
// 3. FILE HANDLING HELPERS
// ==========================================
function getBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

function base64ToBlob(base64, mimeType) {
    const byteCharacters = atob(base64.split(',')[1]);
    const byteArrays = [];
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
        const slice = byteCharacters.slice(offset, offset + 512);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        byteArrays.push(new Uint8Array(byteNumbers));
    }
    return new Blob(byteArrays, { type: mimeType });
}

// ==========================================
// 4. CORE API OPERATIONS (CRUD)
// ==========================================
let globalIncidents = [];

async function loadIncidents() {
    try {
        const response = await fetch(API_URL);
        let data = await response.json();
        globalIncidents = data.reverse();
        renderTable(globalIncidents);
        updateAnalytics();
    } catch (error) {
        console.error("Make sure your custom API server is running!", error);
    }
}

function renderTable(incidents) {
    const tableBody = document.getElementById('incidentTableBody');
    tableBody.innerHTML = '';

    // Update the incident count badge in the header
    document.getElementById('incidentCountBadge').innerText = `${incidents.length} incident${incidents.length !== 1 ? 's' : ''}`;

    if (incidents.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="6" style="padding: 40px; text-align: center; color: var(--text-muted);"><i class="fas fa-search" style="margin-right: 8px;"></i> No incidents found.</td></tr>`;
        return;
    }

    incidents.forEach(inc => {
        // Map status to your new custom CSS classes
        let statusClass = "badge-draft";
        if (inc.status === "Reviewed") statusClass = "badge-reviewed";
        if (inc.status === "Resolved") statusClass = "badge-resolved";

        const dateStr = new Date(inc.createdAt).toLocaleString([], { 
            year: 'numeric', 
            month: '2-digit', 
            day: '2-digit', 
            hour: '2-digit', 
            minute:'2-digit' 
        });

        tableBody.innerHTML += `
            <tr onclick="viewIncident('${inc.id}')">
                <td class="cell-id">${inc.id}</td>
                <td>
                    <div class="cell-title">${inc.title}</div>
                    <div class="cell-sub">Reported by ${inc.creator}</div>
                </td>
                <td><span class="cell-category">${inc.category}</span></td>
                <td><span class="status-badge ${statusClass}" data-status="${inc.status}"><span class="dot"></span>${inc.status}</span></td>
                <td class="cell-sub">${dateStr}</td>
                <td style="text-align: right;">
                    <button class="view-btn" onclick="event.stopPropagation();viewIncident('${inc.id}')"><i class="fas fa-eye" style="margin-right:4px;font-size:11px"></i>View</button>
                </td>
            </tr>
        `;
    });
}

// SEARCH FILTER
document.getElementById('searchInput').addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase().trim();
    if (!query) {
        renderTable(globalIncidents);
        return;
    }
    const filtered = globalIncidents.filter(inc =>
        inc.id.toLowerCase().includes(query) ||
        inc.title.toLowerCase().includes(query) ||
        inc.category.toLowerCase().includes(query) ||
        inc.status.toLowerCase().includes(query)
    );
    renderTable(filtered);
});

// ==========================================
// FILE UPLOAD UI FEEDBACK
// ==========================================
document.getElementById('fileInput').addEventListener('change', function(e) {
    const uploadArea = document.querySelector('.file-upload-area');
    const icon = uploadArea.querySelector('i');
    const title = uploadArea.querySelector('p');
    const subtitle = uploadArea.querySelector('span');

    if (this.files && this.files.length > 0) {
        const fileName = this.files[0].name;
        
        // Change to a success state!
        icon.className = 'fas fa-check-circle';
        icon.style.color = 'var(--green)';
        title.textContent = 'File attached successfully';
        subtitle.textContent = fileName;
        uploadArea.style.borderColor = 'var(--green)';
        uploadArea.style.background = 'var(--green-light)';
    } else {
        resetFileUploadUI();
    }
});

// Helper function to reset the visual state
function resetFileUploadUI() {
    const uploadArea = document.querySelector('.file-upload-area');
    if (!uploadArea) return;
    const icon = uploadArea.querySelector('i');
    const title = uploadArea.querySelector('p');
    const subtitle = uploadArea.querySelector('span');

    // Revert to original styling
    icon.className = 'fas fa-cloud-upload-alt';
    icon.style.color = 'var(--text-muted)';
    title.textContent = 'Click to attach a file';
    subtitle.textContent = 'PDF, Images, Word (.docx), Plain Text';
    uploadArea.style.borderColor = '';
    uploadArea.style.background = '';
}


// CREATE SUBMISSION
document.getElementById('incidentForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    // 1. Target the exact button ID we just added to the HTML
    const submitBtn = document.getElementById('submitIncidentBtn');
    let originalText = "Submit Report";

    // 2. Safely trigger the loading spinner
    if (submitBtn) {
        originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i> Saving...';
        submitBtn.disabled = true;
    }

    try {
        const fileInput = document.getElementById('fileInput');
        const file = fileInput.files[0];
        let fileData = null;
        let fileType = null;

        if (file) {
            fileData = await getBase64(file);
            fileType = file.type;
        }

        const newIncident = {
            id: "INC-" + Math.floor(1000 + Math.random() * 9000),
            title: document.getElementById('title').value,
            category: document.getElementById('category').value,
            description: document.getElementById('desc').value,
            status: "Draft",
            creator: currentUser.username,
            createdAt: new Date().toISOString(),
            fileType: fileType,
            fileData: fileData,
            hasAttachment: !!file
        };

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newIncident)
        });

        if (!response.ok) throw new Error("API rejection");

        closeCreateModal();
        loadIncidents();

    } catch (error) {
        console.error("Database Error:", error);
        alert("System Error: Failed to save. Check server logs.");
    } finally {
        // 3. Safely restore the button
        if (submitBtn) {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }
});

// UPDATE STATUS
async function updateStatus(id, newStatus) {
    // Read from radio cards if available, otherwise use passed value
    const checkedRadio = document.querySelector('input[name="statusPick"]:checked');
    const statusToSave = checkedRadio ? checkedRadio.value : newStatus;
    await fetch(`${API_URL}/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: statusToSave })
    });
    await loadIncidents();
    viewIncident(id); // Refresh the open drawer
}

// DELETE INCIDENT
async function deleteIncident(id) {
    const confirmation = confirm("Are you sure you want to retract this report? This action cannot be undone.");
    if (confirmation) {
        try {
            await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
            closeDetailsPanel();
            await loadIncidents(); 
        } catch (error) {
            console.error("Failed to delete:", error);
            alert("System Error: Could not cancel the report.");
        }
    }
}

// ==========================================
// 5. DETAIL VIEWER & STEPPER LOGIC
// ==========================================

async function fetchIncidentWithFile(id) {
    const response = await fetch(`${API_URL}/${id}`);
    if (!response.ok) throw new Error(`Failed to fetch incident ${id}`);
    return await response.json();
}

async function viewIncident(id) {
    const inc = globalIncidents.find(i => i.id === id);
    if (!inc) return;

    // Open the new Drawer UI
    openDetailsPanel();

    // Populate Text Data
    document.getElementById('detailId').innerText = inc.id;
    document.getElementById('detailTitle').innerText = inc.title;
    document.getElementById('detailCategory').innerText = inc.category;
    document.getElementById('detailDesc').innerText = inc.description || "No description provided.";
    document.getElementById('detailCreator').innerText = inc.creator;
    document.getElementById('detailStatusDisplay').innerText = inc.status; // Updates the Meta Grid
    
    const d = new Date(inc.createdAt);
    document.getElementById('detailDate').innerText = d.toLocaleDateString() + " " + d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

    // --- PROGRESSIVE STEPPER ANIMATION ---
    const stepDraft = document.getElementById('step-draft');
    const stepReviewed = document.getElementById('step-reviewed');
    const stepResolved = document.getElementById('step-resolved');

    // Reset Classes
    [stepDraft, stepReviewed, stepResolved].forEach(step => {
        step.classList.remove('done', 'active');
    });

    if (inc.status === "Draft") {
        stepDraft.classList.add('active');
    } else if (inc.status === "Reviewed") {
        stepDraft.classList.add('done');
        stepReviewed.classList.add('active');
    } else if (inc.status === "Resolved") {
        stepDraft.classList.add('done');
        stepReviewed.classList.add('done');
        stepResolved.classList.add('done');
    }

    // --- ROLE-BASED ACTIONS ---
    const reviewerActions = document.getElementById('reviewerActions');
    const creatorActions = document.getElementById('creatorActions');

    if (currentUser.role === 'Admin' || currentUser.role === 'Reviewer') {
        reviewerActions.style.display = 'flex';
        document.getElementById('detailStatusSelect').value = inc.status;
        const btn = document.getElementById('saveStatusBtn');
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        newBtn.onclick = () => updateStatus(inc.id, document.getElementById('detailStatusSelect').value);
    } else {
        reviewerActions.style.display = 'none';
    }

    if (currentUser.username === inc.creator && inc.status === "Draft") {
        creatorActions.style.display = 'block';
        document.getElementById('cancelReportBtn').onclick = () => deleteIncident(inc.id);
    } else {
        creatorActions.style.display = 'none';
    }

    // Render Preview
    renderPreview(inc, id);
}

// 5b. PREVIEW LOGIC
async function renderPreview(inc, id) {
    const previewWrapper = document.getElementById('previewWrapper');
    const previewContainer = document.getElementById('previewContainer');

    // --- NEW: GOOGLE DRIVE EMBED PREVIEW ---
    if (inc.drive_link) {
        previewWrapper.style.display = 'block';
        
        // Google Drive trick: Convert the /view link into an embeddable /preview link
        const embedUrl = inc.drive_link.replace('/view', '/preview');

        previewContainer.innerHTML = `
            <div style="position: relative; width: 100%; height: 400px; border-radius: 8px; overflow: hidden; border: 1px solid var(--border);">
                <div style="position: absolute; top: 12px; right: 12px; z-index: 10;">
                    <a href="${inc.drive_link}" target="_blank" style="background: var(--text-primary); color: #fff; padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; text-decoration: none; box-shadow: var(--shadow-md); transition: all 0.15s;">
                        <i class="fas fa-external-link-alt" style="margin-right: 4px;"></i> Open in Drive
                    </a>
                </div>
                <iframe src="${embedUrl}" width="100%" height="100%" style="border: none;"></iframe>
            </div>`;
            
        return; // Stop the function here so it doesn't try to load base64 data
    }
    // ----------------------------------------
    
    if (!inc.hasAttachment) {
        previewWrapper.style.display = 'none';
        return;
    }

    previewWrapper.style.display = 'block';
    previewContainer.innerHTML = `<div style="text-align:center; padding: 40px; color: var(--text-muted);"><i class="fas fa-spinner fa-spin" style="font-size: 24px; color: var(--yellow); margin-bottom: 12px;"></i><p>Loading attachment...</p></div>`;

    try {
        const fullInc = await fetchIncidentWithFile(id);
        const savedFileData = fullInc.fileData;

        if (!savedFileData) throw new Error("File empty");

        const downloadBtn = `
            <div style="position: absolute; top: 12px; right: 12px; z-index: 10;">
                <a href="${savedFileData}" download="${inc.id}_Attachment" style="background: var(--text-primary); color: #fff; padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; text-decoration: none; box-shadow: var(--shadow-md);">
                    <i class="fas fa-download" style="margin-right: 4px;"></i> Download
                </a>
            </div>`;

        if (fullInc.fileType === 'application/pdf') {
            const blob = base64ToBlob(savedFileData, 'application/pdf');
            const blobUrl = URL.createObjectURL(blob);
            previewContainer.innerHTML = `<div style="position: relative; width: 100%; height: 400px;">${downloadBtn}<iframe src="${blobUrl}" style="width: 100%; height: 100%; border: none; border-radius: 8px;"></iframe></div>`;
        } else if (fullInc.fileType && fullInc.fileType.startsWith('image/')) {
            previewContainer.innerHTML = `<div style="position: relative; width: 100%; min-height: 200px; display: flex; align-items: center; justify-content: center;">${downloadBtn}<img src="${savedFileData}" style="max-width: 100%; max-height: 400px; border-radius: 8px;" /></div>`;
        } else if (fullInc.fileType.includes('wordprocessingml') || fullInc.fileType === 'application/msword') {
            previewContainer.innerHTML = `<div style="position: relative; width: 100%; height: 400px; background: #fff; overflow-y: auto; border-radius: 8px;">${downloadBtn}<div id="docxCanvas" style="padding: 24px;"></div></div>`;
            setTimeout(() => {
                const blob = base64ToBlob(savedFileData, fullInc.fileType);
                if (typeof docx !== 'undefined') {
                    docx.renderAsync(blob, document.getElementById("docxCanvas")).catch(() => {
                        document.getElementById("docxCanvas").innerHTML = `<p style='color: #dc2626; text-align: center;'>Could not render document.</p>`;
                    });
                }
            }, 100);
        } else {
            previewContainer.innerHTML = `<div style="text-align:center; padding: 40px; position: relative;">${downloadBtn}<i class="fas fa-file-archive" style="font-size: 32px; color: var(--text-muted); margin-bottom: 12px;"></i><p style="font-weight: 500;">Preview Not Supported</p></div>`;
        }
    } catch (err) {
        previewContainer.innerHTML = `<div style="text-align:center; padding: 40px; color: #dc2626;"><i class="fas fa-exclamation-triangle" style="font-size: 24px; margin-bottom: 12px;"></i><p>Failed to Load Attachment</p></div>`;
    }
}

// ==========================================
// 6. ANALYTICS
// ==========================================
function updateAnalytics() {
    const total = globalIncidents.length;
    const pending = globalIncidents.filter(i => i.status === 'Draft' || i.status === 'Reviewed').length;
    const resolved = globalIncidents.filter(i => i.status === 'Resolved').length;

    // Update Dashboard View Stats
    if (document.getElementById('statTotal')) {
        document.getElementById('statTotal').innerText = total;
        document.getElementById('statPending').innerText = pending;
        document.getElementById('statResolved').innerText = resolved;
    }
    
    // Update Analytics View Stats
    if (document.getElementById('analyticsTotal')) {
        document.getElementById('analyticsTotal').innerText = total;
        document.getElementById('analyticsPending').innerText = pending;
        document.getElementById('analyticsResolved').innerText = resolved;
    }
}

// Boot up
loadIncidents();