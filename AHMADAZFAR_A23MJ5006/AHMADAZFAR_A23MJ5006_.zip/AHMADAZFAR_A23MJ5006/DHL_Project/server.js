const jsonServer = require('json-server');
const express = require('express');
const server = jsonServer.create();
const router = jsonServer.router('db.json');
const middlewares = jsonServer.defaults();

// Increase body size limit to 50mb for base64 file uploads
server.use(express.json({ limit: '50mb' }));
server.use(express.urlencoded({ limit: '50mb', extended: true }));

server.use(middlewares);

// --- THE NEW Bouncer (ID Generator) ---
server.use((req, res, next) => {
    // Only intercept POST requests going to the /incidents endpoint
    if (req.method === 'POST' && req.path === '/incidents') {
        
        // 1. Read the current database to look at existing incidents
        const incidents = router.db.get('incidents').value();
        let nextNumber = 1000; // Default starting number if the database is empty

        if (incidents && incidents.length > 0) {
            // 2. Search through all IDs to find the absolute highest number
            const highestNumber = incidents.reduce((max, incident) => {
                // Look for the numbers inside the string (e.g., extracts 8321 from "INC-8321")
                const match = incident.id && String(incident.id).match(/\d+/);
                if (match) {
                    const num = parseInt(match[0], 10);
                    return num > max ? num : max;
                }
                return max;
            }, 0);

            if (highestNumber > 0) {
                nextNumber = highestNumber + 1;
            }
        }

        // 3. Attach the brand new formatted ID to the incoming data!
        req.body.id = `INC-${nextNumber}`;
    }
    
    // 4. Pass the data to the router to actually save it in db.json
    next();
});
// ---------------------------------------

server.use(router);

server.listen(3000, () => {
    console.log('JSON Server running at http://localhost:3000');
});