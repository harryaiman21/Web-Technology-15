// Redirect to login if no session found
const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
if (!currentUser) window.location.href = 'index.html';

document.getElementById('nav-user').textContent = `👤 ${currentUser.username}`;

// Global array — holds all articles so we can filter without re-fetching
let allArticles = [];

// --- FETCH all articles from JSON Server ---
async function loadArticles() {
  const res = await fetch(`${API}/articles`);
  allArticles = await res.json();
  renderArticles(allArticles);
}

// --- FILTER articles based on the 4 filter inputs ---
function filterArticles() {
  const search  = document.getElementById('search-input').value.toLowerCase();
  const status  = document.getElementById('filter-status').value;
  const tag     = document.getElementById('filter-tag').value.toLowerCase();
  const creator = document.getElementById('filter-creator').value.toLowerCase();

  const filtered = allArticles.filter(article => {
    const matchSearch  = !search || article.title.toLowerCase().includes(search) || article.content.toLowerCase().includes(search);
    const matchStatus  = !status || article.status === status;
    const matchTag     = !tag    || article.tags.some(t => t.toLowerCase().includes(tag));
    const matchCreator = !creator || article.creator.toLowerCase().includes(creator);
    return matchSearch && matchStatus && matchTag && matchCreator;
  });

  renderArticles(filtered);
}

// --- BUILD the article cards and inject into the page ---
function renderArticles(articles) {
  const list = document.getElementById('articles-list');

  if (articles.length === 0) {
    list.innerHTML = '<p class="empty-msg">No articles found.</p>';
    return;
  }

  list.innerHTML = articles.map(article => `
    <div class="article-card">

      <div class="article-header">
        <h3>${article.title}</h3>
        <span class="badge badge-${article.status.toLowerCase()}">${article.status}</span>
      </div>

      <p class="article-meta">
        👤 ${article.creator} &nbsp;|&nbsp;
        📅 ${new Date(article.createdAt).toLocaleDateString()} &nbsp;|&nbsp;
        🏷️ ${article.tags.join(', ')} &nbsp;|&nbsp;
        📎 ${article.fileName ? article.fileName : 'No file'}
      </p>

      <p class="article-preview">${article.content.substring(0, 200)}...</p>

      <div class="history">
        <strong>History:</strong>
        ${article.history.map(h =>
          `<span class="history-item">${h.status} — ${new Date(h.changedAt).toLocaleDateString()}</span>`
        ).join(' → ')}
      </div>

      <div class="article-actions">
        ${article.status === 'Draft' ? `
          <button class="btn-action reviewed" onclick="updateStatus('${article.id}', 'Reviewed')">
            Mark as Reviewed
          </button>` : ''}
        ${article.status === 'Reviewed' ? `
          <button class="btn-action published" onclick="updateStatus('${article.id}', 'Published')">
            Mark as Published
          </button>` : ''}
        <button class="btn-action delete" onclick="deleteArticle('${article.id}')">
          Delete
        </button>
      </div>

    </div>
  `).join('');
}

// --- UPDATE status — sends a PUT request to JSON Server ---
async function updateStatus(id, newStatus) {
  // Find the full article object from our local array
  const article = allArticles.find(a => a.id === id);

  // Append the new status change to history
  const updatedHistory = [
    ...article.history,
    { status: newStatus, changedAt: new Date().toISOString() }
  ];

  // Spread ...article keeps all existing fields, then we override status and history
  const updatedArticle = { ...article, status: newStatus, history: updatedHistory };

  const res = await fetch(`${API}/articles/${id}`, {
    method:  'PUT',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(updatedArticle)
  });

  if (res.ok) {
    loadArticles(); // re-fetch and re-render the whole list
  } else {
    alert('Update failed — is JSON Server still running?');
  }
}

// --- DELETE an article ---
async function deleteArticle(id) {
  if (!confirm('Delete this article? This cannot be undone.')) return;

  const res = await fetch(`${API}/articles/${id}`, { method: 'DELETE' });

  if (res.ok) {
    loadArticles();
  } else {
    alert('Delete failed — is JSON Server still running?');
  }
}

function logout() {
  sessionStorage.clear();
  window.location.href = 'index.html';
}

// Run on page load
loadArticles();