// The URL of our JSON Server mock backend
const API = 'http://localhost:3000';

// --- LOGIN ---
async function login() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();

  // Fetch all users from the mock API
  // async/await lets us wait for the network response before continuing
  const res = await fetch(`${API}/users`);
  const users = await res.json();

  // .find() searches the array for the first user that matches both fields
  const match = users.find(u => u.username === username && u.password === password);

  if (match) {
    // Store the logged-in user in sessionStorage so other pages can read it
    sessionStorage.setItem('currentUser', JSON.stringify(match));
    // Redirect to the dashboard
    window.location.href = 'dashboard.html';
  } else {
    // Show the error message
    document.getElementById('error-msg').classList.remove('hidden');
  }
}

// Hides the error message when the user starts typing again
function clearError() {
  document.getElementById('error-msg').classList.add('hidden');
}