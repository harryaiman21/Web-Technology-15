// Check login — if no user in session, kick back to login page
const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
if (!currentUser) window.location.href = 'index.html';

// Show the logged-in username in the navbar
document.getElementById('nav-user').textContent = `👤 ${currentUser.username}`;

// --- CREATE ARTICLE ---
async function createArticle() {
  const title   = document.getElementById('art-title').value.trim();
  const tags    = document.getElementById('art-tags').value.trim();
  const content = document.getElementById('art-content').value.trim();
  const status  = document.getElementById('art-status').value;
  const fileInput = document.getElementById('art-file');

  // Basic validation — title and content are required
  if (!title || !content) {
    showMsg('Please fill in Title and Content.', 'error');
    return;
  }

  // Read the attached file name if one was selected
  const fileName = fileInput.files.length > 0 ? fileInput.files[0].name : null;

  // Build the article object we'll send to JSON Server
  const article = {
    title:     title,
    tags:      tags.split(',').map(t => t.trim()),  // turn "a, b" into ["a","b"]
    content:   content,
    status:    status,
    creator:   currentUser.username,
    createdAt: new Date().toISOString(),             // current timestamp
    fileName:  fileName,
    history:   [{ status: status, changedAt: new Date().toISOString() }]
  };

  // POST sends a new record to the API — JSON Server saves it to db.json
  const res = await fetch(`${API}/articles`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(article)   // convert JS object → JSON string
  });

  if (res.ok) {
    showMsg('✅ Article saved successfully!', 'success');
    clearForm();
  } else {
    showMsg('❌ Something went wrong. Is JSON Server running?', 'error');
  }
}

// Clears all form fields after a successful save
function clearForm() {
  document.getElementById('art-title').value   = '';
  document.getElementById('art-tags').value    = '';
  document.getElementById('art-content').value = '';
  document.getElementById('art-status').value  = 'Draft';
  document.getElementById('art-file').value    = '';
}

// Shows a feedback message below the Save button
function showMsg(text, type) {
  const msg = document.getElementById('save-msg');
  msg.textContent = text;
  msg.className = type === 'success' ? 'success-msg' : 'error-msg';
}

// Logout — clear session and go back to login
function logout() {
  sessionStorage.clear();
  window.location.href = 'index.html';
}