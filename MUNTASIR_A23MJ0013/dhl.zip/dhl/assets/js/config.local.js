// LOCAL ONLY — this file is gitignored. Do not commit real keys.
// Loaded after config.js to override browser-safe values for local development.

window.RF_CONFIG = Object.assign(window.RF_CONFIG || {}, {
  GOOGLE_API_KEY: "AIzaSyD3a22gZsN3GBXnuUFO9vdoA1LagadyZ-s",
});
