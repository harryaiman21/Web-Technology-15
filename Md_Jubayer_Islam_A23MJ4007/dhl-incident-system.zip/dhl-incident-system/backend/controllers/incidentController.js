import Incident from '../models/Incident.js';

// ---> PHASE 3 ADDITIONS FOR EMAIL AUTOMATION <---
import Department from '../models/Department.js';
import { sendDepartmentAlert } from '../utils/emailService.js';
// ------------------------------------------------

const generateTicketId = () => {
    return `INC-${Math.floor(Math.random() * 90000) + 10000}`;
};

const generateIncidentId = () => {
    const date = new Date();
    const ymd = date.toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.floor(1000 + Math.random() * 9000);
    return `DHL-${ymd}-${random}`;
};

// @desc    Get all incidents
// @route   GET /api/incidents
export const getIncidents = async (req, res) => {
    try {
        const incidents = await Incident.find({}).sort({ createdAt: -1 }).lean();
        res.status(200).json(incidents);
    } catch (error) {
        console.error("❌ Error fetching incidents:", error);
        res.status(500).json({ message: 'Failed to fetch incidents', error: error.message });
    }
};

// @desc    Get incidents for a specific customer
// @route   GET /api/incidents/customer/:email
export const getCustomerIncidents = async (req, res) => {
    try {
        const incidents = await Incident.find({ customerEmail: req.params.email })
            .sort({ createdAt: -1 })
            .lean();

        res.status(200).json(incidents);
    } catch (error) {
        console.error(`❌ Error fetching incidents for ${req.params.email}:`, error);
        res.status(500).json({ message: 'Failed to fetch customer incidents', error: error.message });
    }
};

// @desc    Get a single incident by MongoDB _id, ticketId, or incidentId
// @route   GET /api/incidents/:id
export const getIncidentById = async (req, res) => {
    try {
        let incident = await Incident.findById(req.params.id).catch(() => null);

        if (!incident) {
            incident = await Incident.findOne({
                $or: [
                    { ticketId: req.params.id },
                    { incidentId: req.params.id }
                ]
            });
        }

        if (!incident) {
            return res.status(404).json({ message: 'Incident not found in the Vault.' });
        }

        res.status(200).json(incident);
    } catch (error) {
        console.error(`❌ Error fetching incident ${req.params.id}:`, error);
        res.status(500).json({ message: 'Error retrieving incident details', error: error.message });
    }
};

// @desc    Create a new incident manually
// @route   POST /api/incidents
// @desc    Create a new incident manually (or via Draft Builder Publish)
// @route   POST /api/incidents
export const createIncident = async (req, res) => {
    try {
        const newTicketId = generateTicketId();
        const newIncidentId = req.body.incidentId || generateIncidentId();

        const initialTracking = [
            {
                label: `Ingested via ${req.body.source || 'Manual Entry'}`,
                timestamp: new Date().toLocaleString(),
                status: 'completed'
            },
            {
                label: 'Pending Manual Routing / Review',
                timestamp: 'Current',
                status: 'current'
            }
        ];

        const incident = new Incident({
            ...req.body,
            incidentId: newIncidentId,
            ticketId: req.body.ticketId || newTicketId,
            rawDescription: req.body.rawDescription || req.body.rawText || req.body.description || "Manual incident entry - no description provided.",
            tracking: req.body.tracking || initialTracking
        });

        const createdIncident = await incident.save();

        if (req.io) {
            req.io.emit('newIncident', createdIncident);
        }

        console.log(`✅ Incident ${createdIncident.ticketId} / ${createdIncident.incidentId} published to Vault!`);

        // ---> NEW: AUTOMATED EMAIL TRIGGER FOR PUBLISHED DRAFTS <---
        if (createdIncident.department && createdIncident.department !== 'Unassigned') {
            const assignedDept = await Department.findOne({ name: createdIncident.department });

            if (assignedDept && assignedDept.email) {
                sendDepartmentAlert(assignedDept.email, createdIncident);
                console.log(`📧 Assignment email sent to ${assignedDept.name}`);
            }
        }
        // ------------------------------------------------------------

        res.status(201).json(createdIncident);

    } catch (error) {
        console.error("❌ Error creating manual incident:", error);
        res.status(400).json({ message: 'Failed to create incident', error: error.message });
    }
};

// @desc    Update incident status/assignee
// @route   PUT /api/incidents/:id
export const updateIncident = async (req, res) => {
    try {
        const { status, assignee, department, trackingUpdate } = req.body;
        const incident = await Incident.findById(req.params.id);

        if (!incident) {
            return res.status(404).json({ message: 'Incident not found' });
        }

        // We capture the OLD department to see if it changed during this update
        const isNewDepartment = department && department !== incident.department;

        if (status) incident.status = status;
        if (assignee) incident.assignee = assignee;
        if (department) incident.department = department;

        if (trackingUpdate) {
            if (incident.tracking && incident.tracking.length > 0) {
                incident.tracking.forEach(t => {
                    if (t.status === 'current') t.status = 'completed';
                });
            }

            incident.tracking.push(trackingUpdate);
        }

        const updatedIncident = await incident.save();

        if (req.io) {
            req.io.emit('incidentUpdated', updatedIncident);
        }

        console.log(`🔄 Incident ${incident.ticketId} updated successfully!`);

        // ---> PHASE 3: AUTOMATED EMAIL TRIGGER <---
        // Only send an email if the department was actually changed/assigned during this update
        if (isNewDepartment && updatedIncident.department !== 'Unassigned') {
            const assignedDept = await Department.findOne({ name: updatedIncident.department });

            if (assignedDept && assignedDept.email) {
                // Fire and forget - don't await so the UI responds instantly
                sendDepartmentAlert(assignedDept.email, updatedIncident);
                console.log(`📧 Re-route email sent to ${assignedDept.name}`);
            }
        }
        // ------------------------------------------

        res.status(200).json(updatedIncident);

    } catch (error) {
        console.error(`❌ Error updating incident ${req.params.id}:`, error);
        res.status(400).json({ message: 'Failed to update incident', error: error.message });
    }
};

// @desc    Delete a single incident
// @route   DELETE /api/incidents/:id
export const deleteIncident = async (req, res) => {
    try {
        const incident = await Incident.findByIdAndDelete(req.params.id);
        if (!incident) {
            return res.status(404).json({ message: 'Incident not found' });
        }

        // ---> THE FIX: Decrement the department counter <---
        if (incident.department && incident.department !== 'Unassigned') {
            await Department.findOneAndUpdate(
                { name: incident.department },
                { $inc: { activeIncidentsCount: -1 } } // Subtracts 1 from the count
            ).catch(err => console.error("Failed to decrement department count:", err));
        }

        console.log(`🗑️ Incident ${incident.ticketId} deleted successfully!`);
        res.status(200).json({ message: 'Incident removed successfully' });
    } catch (error) {
        console.error(`❌ Error deleting incident ${req.params.id}:`, error);
        res.status(500).json({ message: 'Failed to delete incident', error: error.message });
    }
};

// @desc    DANGEROUS: Delete ALL incidents (Dev Mode Only)
// @route   DELETE /api/incidents/wipe-all
export const wipeAllIncidents = async (req, res) => {
    try {
        await Incident.deleteMany({});

        // ---> THE FIX: Reset all department counters to 0 <---
        await Department.updateMany({}, { activeIncidentsCount: 0 });

        console.log("🔥 ALL INCIDENTS DELETED AND DEPARTMENT COUNTERS RESET 🔥");
        res.status(200).json({ message: "Database wiped and counters reset!" });
    } catch (error) {
        console.error("❌ Error wiping database:", error);
        res.status(500).json({ message: "Failed to wipe database", error: error.message });
    }
};