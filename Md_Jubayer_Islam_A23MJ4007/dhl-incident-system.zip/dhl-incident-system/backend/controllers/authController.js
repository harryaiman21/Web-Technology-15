import Employee from '../models/Employee.js';
import jwt from 'jsonwebtoken';

const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d',
    });
};

export const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        console.log(`\n🔍 --- LOGIN ATTEMPT ---`);
        console.log(`📧 Email entered: ${email}`);

        // 1. Find the user
        const user = await Employee.findOne({ email });

        if (!user) {
            console.log(`❌ ERROR: No user found in database with email: ${email}`);
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        console.log(`✅ User found: ${user.name}`);
        console.log(`🔑 Hashed password in DB: ${user.password.substring(0, 15)}...`);

        // 2. Check password
        const isMatch = await user.matchPassword(password);

        if (!isMatch) {
            console.log(`❌ ERROR: Password did not match the bcrypt hash!`);
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        console.log(`✅ Password matched!`);

        // 3. Check status
        if (user.status !== 'Active') {
            console.log(`❌ ERROR: Account is marked as Inactive.`);
            return res.status(401).json({ message: 'Account is deactivated. Please contact IT.' });
        }

        console.log(`🚀 LOGIN SUCCESS! Generating token...`);
        console.log(`-----------------------\n`);

        res.json({
            _id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
            department: user.department,
            token: generateToken(user._id),
        });

    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({ message: 'Server error during login' });
    }
};