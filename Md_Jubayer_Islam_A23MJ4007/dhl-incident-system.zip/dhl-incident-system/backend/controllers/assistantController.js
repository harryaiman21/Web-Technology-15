import Incident from '../models/Incident.js';
import OpenAI from 'openai'; // <-- Switched from ollama to openai

// Initialize OpenAI using your .env key
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

export const chatWithAssistant = async (req, res) => {
    try {
        const { message, history } = req.body;

        const activeIncidents = await Incident.find({ status: { $ne: 'Resolved' } }).limit(20);

        const dbContext = activeIncidents.map(inc =>
            `[ID: ${inc.incidentId} | Created: ${new Date(inc.createdAt).toLocaleString()} | Status: ${inc.status} | Priority: ${inc.priority} | Dept: ${inc.department} | Summary: ${inc.aiSummary}]`
        ).join('\n');

        // ==========================================
        // THE NEW "NATURAL DISPATCHER" SYSTEM PROMPT
        // ==========================================
        const systemPrompt = `
            You are ResoBot, an expert DHL dispatcher and Copilot. You are talking to a DHL admin.
            
            Current System Time: ${new Date().toLocaleString()}
            
            PERSONALITY & RULES:
            1. Speak like a highly competent, natural human colleague. Be conversational but concise.
            2. NEVER use robotic filler phrases like "How can I assist you today?", "It seems like you asked...", or "As an AI...".
            3. If the user just says "hi", reply with a casual, quick greeting (e.g., "Hey! Need an update on the queue or a specific incident?").
            4. When asked about a specific incident, give the most critical info immediately: What it is, the priority, its status, and how long it has been sitting there.
            5. Do not offer to "keep an eye on it" (you don't have background tasks). Instead, suggest an action like "Should I flag this for review?" or just present the facts.
            6. Use formatting (bolding) to make IDs, Statuses, and Priorities easy to scan.

            LIVE DATABASE CONTEXT:
            ${dbContext || "No active incidents right now."}
        `;

        const messages = [
            { role: "system", content: systemPrompt },
            ...history,
            { role: "user", content: message }
        ];

        console.log("🧠 Routing Copilot Chat to OpenAI (GPT-4o)...");

        // Call the OpenAI API instead of local Ollama
        const aiResponse = await openai.chat.completions.create({
            model: 'gpt-4o', // You can also use 'gpt-4o-mini' here for faster/cheaper responses
            messages: messages,
            temperature: 0.4, // Slightly higher temperature makes it sound more natural
            top_p: 0.9
        });

        res.status(200).json({
            // OpenAI's response structure is slightly different than Ollama's
            reply: aiResponse.choices[0].message.content
        });

    } catch (error) {
        console.error("❌ OpenAI Assistant Error:", error);
        res.status(500).json({ reply: "I'm offline right now. Please check my connection to the OpenAI servers." });
    }
};