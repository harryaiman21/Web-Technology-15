import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema(
    {
        type: {
            type: String,
            enum: ['bot', 'incident', 'error', 'system'],
            required: true
        },
        title: { type: String, required: true },
        message: { type: String, required: true },
        read: { type: Boolean, default: false }
    },
    { timestamps: true }
);

export default mongoose.model('Notification', notificationSchema);