import express from 'express';
import multer from 'multer';

import {
    getIncidents,
    createIncident,
    updateIncident,
    getCustomerIncidents,
    getIncidentById,
    deleteIncident,
    wipeAllIncidents
} from '../controllers/incidentController.js';

import { processUnstructuredData } from '../controllers/aiController.js';
import { chatWithAssistant } from '../controllers/assistantController.js';
import { processGoogleDriveFile } from '../controllers/uipathController.js';
import { runUiPathBot } from '../controllers/botController.js'; // <-- NEW IMPORT

const router = express.Router();

// Multer setup for temporary file storage
const upload = multer({ dest: 'uploads/' });

// --- DEV / CLEANUP ROUTES ---
router.delete('/wipe-all', wipeAllIncidents);

// --- STANDARD CRUD ROUTES ---
router.route('/')
    .get(getIncidents)
    .post(createIncident);

// --- CUSTOMER ROUTES ---
router.get('/customer/:email', getCustomerIncidents);

// --- UIPATH GOOGLE DRIVE PROCESSING ROUTE ---
router.post('/uipath-drive', processGoogleDriveFile);

// --- MANUAL UIPATH BOT TRIGGER ROUTE ---
router.post('/run-bot', runUiPathBot); // <-- NEW ROUTE

// --- AI FILE PROCESSING ROUTE ---
router.post('/ai-process', upload.array('file', 5), (req, res, next) => {
    console.log('BODY:', req.body);
    console.log('FILES:', req.files);
    next();
}, processUnstructuredData);

// --- ASSISTANT CHATBOT ROUTE ---
router.post('/chat', chatWithAssistant);

// --- INCIDENT DETAILS ROUTE ---
router.route('/:id')
    .get(getIncidentById)
    .put(updateIncident)
    .delete(deleteIncident);

export default router;