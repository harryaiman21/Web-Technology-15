import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';

import Layout from './components/Layout'; // Admin Layout

// --- Admin Pages ---
import Dashboard from './pages/Admin/Dashboard';
import Vault from './pages/Admin/Vault';
import DraftBuilder from './pages/Admin/DraftBuilder';
import Departments from './pages/Admin/Departments';
import BotControl from './pages/Admin/BotControl';
import EmployeeManager from './pages/Admin/EmployeeManager';
import NotificationsPage from './pages/Admin/NotificationsPage';

// --- Auth Pages ---
import Login from './pages/Login';
import Logout from './pages/Logout';

// --- Route Protectors ---
const ProtectedRoute = ({ children }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return children;
};

function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <BrowserRouter>
          <Routes>
            {/* --- PUBLIC ROUTES --- */}
            <Route path="/login" element={<Login />} />
            <Route path="/logout" element={<Logout />} />

            {/* --- PROTECTED ADMIN ROUTES --- */}
            <Route path="/admin" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
              <Route index element={<Dashboard />} />
              <Route path="vault" element={<Vault />} />
              <Route path="draft" element={<DraftBuilder />} />
              <Route path="departments" element={<Departments />} />
              <Route path="employees" element={<EmployeeManager />} />
              <Route path="bot-control" element={<BotControl />} />
              <Route path="notifications" element={<NotificationsPage />} />
            </Route>

            {/* Root route handling */}
            <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
              <Route index element={<Dashboard />} />
              <Route path="vault" element={<Vault />} />
              <Route path="draft" element={<DraftBuilder />} />
              <Route path="departments" element={<Departments />} />
              <Route path="employees" element={<EmployeeManager />} />
              <Route path="bot-control" element={<BotControl />} />
              <Route path="notifications" element={<NotificationsPage />} />
            </Route>

          </Routes>
        </BrowserRouter>
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;