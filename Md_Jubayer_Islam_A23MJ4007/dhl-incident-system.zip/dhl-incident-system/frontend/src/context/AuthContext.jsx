import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    // Check if user is already logged in on page load
    useEffect(() => {
        const storedUser = localStorage.getItem('resobot_user');
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }
        setIsLoading(false);
    }, []);

    // REAL Backend Login Call
    const login = async (email, password) => {
        try {
            const response = await fetch('http://localhost:5001/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                // Generate initials for the UI avatar (e.g., "Md Jubayer" -> "MJ")
                const initials = data.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();

                const userData = { ...data, initials };

                setUser(userData);
                localStorage.setItem('resobot_user', JSON.stringify(userData));
                return { success: true };
            } else {
                return { success: false, message: data.message || 'Login failed' };
            }
        } catch (error) {
            console.error("Login connection error:", error);
            return { success: false, message: 'Server connection failed' };
        }
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('resobot_user');
    };

    if (isLoading) return null; // Prevent flicker while checking local storage

    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};